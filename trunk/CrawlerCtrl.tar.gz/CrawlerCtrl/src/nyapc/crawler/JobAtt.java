package nyapc.crawler;

public class JobAtt {
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	public String getSeed() {
		return Seed;
	}
	public void setSeed(String seed) {
		Seed = seed;
	}
	public String getSeedType() {
		return SeedType;
	}
	public void setSeedType(String seedType) {
		SeedType = seedType;
	}
	private int Id;
	private String  Name;
	private String  Comment;

	private String  Seed;
	private String  SeedType;
	
	private String createTime;
	private String updateTime;
	private String jobStat;
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getJobStat() {
		return jobStat;
	}
	public void setJobStat(String jobStat) {
		this.jobStat = jobStat;
	}
}
