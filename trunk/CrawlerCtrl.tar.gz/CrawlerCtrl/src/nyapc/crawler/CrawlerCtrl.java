package nyapc.crawler;


import java.io.IOException;
import java.io.StringReader;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;


import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import nyapc.crawler.dao.AeSimpleSHA1;
import nyapc.crawler.dao.AgentDao;


import nyapc.crawler.dao.ChlDao;
import nyapc.crawler.dao.ColAtt;
import nyapc.crawler.dao.ColDao;
import nyapc.crawler.dao.CrawlerDao;
import nyapc.crawler.dao.IdxAtt;
import nyapc.crawler.dao.IdxDao;
import nyapc.crawler.dao.JobDao;

import nyapc.crawler.dao.TaskDao;
import nyapc.crawler.dao.UrlAtt;
import nyapc.crawler.dao.UrlDao;
import nyapc.crawler.dao.WrapAtt;
import nyapc.crawler.dao.WrapperDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


@WebService(endpointInterface = "nyapc.crawler.CrawlerCtrlInter",
		serviceName = "CrawlerCtrl",
		portName="CrawlerCtrlPort")
		public class CrawlerCtrl implements CrawlerCtrlInter {
	private static Log log = LogFactory.getLog(CrawlerCtrl.class.getName());
	class UrlId
	{
		public int uid;
		public String url;
	};

	class WrapUrl
	{
		public int wrapid;
		public int wrapver;
		public List<UrlId> urlList;
		public int job_id;

		public String type;
	};

	class WrapUrlQueue
	{
		public int wrapid;
		public int wrapver;
		public Queue<UrlId> urlList;
		public int job_id;

		public String type;
	};

	public static Queue<WrapUrlQueue> urls = new LinkedBlockingDeque<WrapUrlQueue>();
	private static BlockingQueue<String> testq = new LinkedBlockingDeque<String>();
	//private static BlockingQueue<Task> taskq = new LinkedBlockingDeque<Task>();
	//private static BlockingQueue<Task> wraptaskq = new LinkedBlockingDeque<Task>();

	private static ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
	private  ChlDao chldao=(ChlDao)ctx.getBean("ChlDao");
	private  ColDao coldao=(ColDao)ctx.getBean("ColDao");
	private  UrlDao urldao=(UrlDao)ctx.getBean("UrlDao");
	private  WrapperDao wrapdao=(WrapperDao)ctx.getBean("WrapDao");
	private  JobDao jobdao=(JobDao)ctx.getBean("JobDao");
	private  IdxDao idxdao=(IdxDao)ctx.getBean("IdxDao");

	private  AgentDao agentdao=(AgentDao)ctx.getBean("AgentDao");
	private  CrawlerDao crawlerdao=(CrawlerDao)ctx.getBean("CrawlerDao");
	private  TaskDao taskdao=(TaskDao)ctx.getBean("TaskDao");

	static {
		log.debug("######### static block");
		TaskDao taskdao=(TaskDao)ctx.getBean("TaskDao");
		if( taskdao!=null){
			log.debug("#########ss  into ");
		taskdao.restartTomcat();
		}else{
			log.debug("######### null");
		}


		Thread pt = new Thread(new Crawler());
		pt.start();		
	}

	public CrawlerCtrl()
	{
		//		PropertyConfigurator.configure("log4j.xml");
		//        log.debug("tttttt");
	}
	/*
	 * test code
	 */

	/*	public static void main(String args[]) {
		 CrawlerCtrl chli=new CrawlerCtrl();

		try {
			 final String hash=AeSimpleSHA1.SHA1("111111");
			 int[] jobs=chli.getJobID();
			 for(int job:jobs)
			 {
				 log.debug("id:"+job);
			 }
			 String wrap=chli.getWrapper(1);
			 log.debug("wrap:"+wrap);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			log.debug(e.toString());
		} 

	 }*/

	@Override
	public Task getWrapTask(int cid,int num) {
		Task ret=null;

		//task，先从task表冲取status=10的
		if(ret == null){ 
			int jid = taskdao.getJobIdFromTask(cid,"10");//from task_list
			if(jid>0){
				ret = taskdao.getTask(cid,jid,"10");
			}
			log.debug("1111111111111");
		}

		if(ret == null){
			ret = takeWrapTask(cid);
		}

		//		//channel
		//		if(ret == null){ 
		//			int jid = taskdao.getJobId("1","9");
		//			if(jid>0){
		//				ret = taskdao.getTaskChannel(cid,jid,"1",num,"9","10");
		//			}
		//			log.debug("2222222");
		//		}
		//		
		//		
		//		//column
		//		if(ret == null){ 
		//			//最近的10条50％为9，才retun task，否则为null
		//			int jid = taskdao.getJobId("2","9");
		//			if(jid>0){
		//				ret = taskdao.getTaskColumn(cid,jid,"2",num,"9","10");
		//			}
		//			log.debug("333333333");
		//		}
		//
		//		//url
		//		if(ret == null){ 
		//			//最近的20条50％为9，才retun task，否则为null
		//			int jid = taskdao.getJobId("3","9");
		//			if(jid>0){
		//				ret = taskdao.getTaskUrl(cid,jid,"3",num,"9","10");
		//			}
		//			log.debug("4444");
		//		}

		//wrapdao.updateStatByWrapId(ret.getWrap_id(),"0"); //这里不再置成0，置成0，改在updateWrapper处。

		return ret;
	}

	@Override
	public Task getWrapInvalidTask(int cid,int num) {
		Task ret=null;

		//task，先从task表冲取status=11的
		if(ret == null){ 
			int jid = taskdao.getJobIdFromTask(cid,"11");//from task_list
			if(jid>0){
				ret = taskdao.getTask(cid,jid,"11");
			}
			log.debug("1111111111111");
		}




		//channel
		if(ret == null){ 
			int jid = taskdao.getJobIdByWrapInvalid("1");
			if(jid>0){
				ret = taskdao.getTaskChannel(cid,jid,"1",num,"10","11");
			}
			log.debug("2222222");
		}


		//column
		if(ret == null){ 
			//最近的10条50％为9，才retun task，否则为null
			int jid = taskdao.getJobIdByWrapInvalid("2");
			if(jid>0){
				ret = taskdao.getTaskColumn(cid,jid,"2",num,"10","11");
			}
			log.debug("333333333");
		}

		//url
		if(ret == null){ 
			//最近的20条50％为9，才retun task，否则为null
			int jid = taskdao.getJobIdByWrapInvalid("3");
			if(jid>0){
				ret = taskdao.getTaskUrl(cid,jid,"3",num,"10","11");
			}
			log.debug("4444");
		}

		//置成1，表示正在进行中
		wrapdao.updateStatByWrapId(ret.getWrap_id(),"1");		

		return ret;
	}


	@Override
	public String getWrapper(int id) {
		WrapAtt tmp=wrapdao.getWrap(id);
		return tmp.getWrapper();
	}

	@Override
	public boolean updateWrapper(String wrap, int id,int taskid) {
		//wraptask完成，从9错误——0（未做状态）
		//目前，学习成功和失败，都修改３＋１的状态到０，回头有可能优化
		if(wrap.length()>0)
		{
			log.debug("111111111");
			boolean flag1 = wrapdao.updateWrap(wrap, id);
		}


		WrapAtt  wrapAtt= wrapdao.getWrap(id);
		if(wrapAtt!=null){
			if("1".equals(wrapAtt.getType())){
				//应该只把状态为9,10的给置成0
				chldao.updateStatByJobIdAndStatus(wrapAtt.getJobid(),"9", "0");
				chldao.updateStatByJobIdAndStatus(wrapAtt.getJobid(),"10", "0");
			}else if("2".equals(wrapAtt.getType())){
				//应该只把状态为9,10的给置成0
				coldao.updateStatByJobIdAndStatus(wrapAtt.getJobid(),"9", "0");
				coldao.updateStatByJobIdAndStatus(wrapAtt.getJobid(),"10", "0");
			}else if("3".equals(wrapAtt.getType())){
				//应该只把状态为9,10的给置成0
				urldao.updateStatByJobIdAndStatus(wrapAtt.getJobid(),"9", "0");
				urldao.updateStatByJobIdAndStatus(wrapAtt.getJobid(),"10", "0");
			}
			taskdao.updateStatByTaskId(taskid, "2");//完成
			//置成-1，重新学习完成
			wrapdao.updateStatByWrapId(wrapAtt.getId(),"-1");				
		}
		return true;
	}

	@Override
	public boolean updateWrapperCheckOk(String wrap, int wrapId) {
		boolean rtn = false;		
		if(wrap.length()>0)
		{
			boolean flag1 = wrapdao.updateWrap(wrap, wrapId);
			//置成0，wrap重新可用
			wrapdao.updateStatByWrapId(wrapId,"0");				
			rtn = true;
		}
		return rtn;
	}

	@Override
	public int getStat(int cid) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override	
	public boolean putResult(String res, int cid) {
		// TODO Auto-generated method stub
		try { 

			res = res.trim();


			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance(); 
			DocumentBuilder builder = factory.newDocumentBuilder();
			StringReader reader = new StringReader( res );
			InputSource inputSource = new InputSource( reader );
			inputSource.setEncoding("utf-8");
			Document document = builder.parse(inputSource);
			Element docEle=document.getDocumentElement();

			int  taskId = Util.str2int(docEle.getAttribute("id"));
			String type= docEle.getAttribute("type");
			log.debug("type:"+type);
			log.debug("taskId:"+taskId);
			
			if(taskId>0){
				if(type.equals("1")){
					//频道  
					NodeList resultlist=docEle.getElementsByTagName("Result");
					if(resultlist.getLength()>0){
						Map<Integer,Integer> uidMap=new HashMap<Integer,Integer>();
						//有数据
						for(int iresult=0;iresult<resultlist.getLength();iresult++)
						{
							Element colresult=(Element) resultlist.item(iresult);
							String url=colresult.getAttribute("url");
							String parurl=Util.GetUrlDir(url);
							String siteurl=Util.GetUrlSite(url);

							int chl_id=Integer.parseInt(colresult.getAttribute("uid"));
							int job_id=chldao.getJobId(chl_id);
							String error=colresult.getAttribute("error");
							if(error!=null&&error.length()>0)
							{
								//Document load error
								if(error.equals("5"))
								{
									chldao.updateStat(chl_id, "9");
								}else
								{
									chldao.updateFailCount(chl_id);
									if(chldao.getFailCount(chl_id)>3){
										//错误超过3次，才更新成2
										chldao.resetFailCount(chl_id);
										chldao.updateStat(chl_id, "2");
									}else{
										chldao.updateStat(chl_id, "0");
									}
								}
							}else
							{
								int colCount=0;
								NodeList nl=colresult.getElementsByTagName("Columns");
								if(nl.getLength()>0)
								{ 
									Element cols=(Element) nl.item(0);

									NodeList collist=cols.getElementsByTagName("Column");
									if(collist.getLength()>0){
										//set 2
										for(int i=0;i<collist.getLength();i++)
										{
											Element col=(Element) collist.item(i);
											String colName= Util.strNotNull(col.getAttribute("name"));
											String colUrl= Util.strNotNull(col.getAttribute("url"));
											//filter the url:delet '#',"javascript",
											colUrl = Util.BuildUrl(colUrl, parurl, siteurl);
											if(colUrl.length()==0)
												continue;
											colCount++;
											
											ColAtt cola=new ColAtt();
											cola.setChlId(chl_id);
											cola.setJobId(job_id);
											cola.setName(colName);//应该可以为null,数据库已经处理
											cola.setUrl(Util.strNotNull(colUrl));//不能为null

											String hash=AeSimpleSHA1.SHA1(cola.getUrl());
											int colid=coldao.GetId(hash);

											if(colid<=0 && !"".equals(cola.getUrl())){
												colid=coldao.puttCol(cola);
											}else{
												//栏目已经存在，更新状态为col_stat=0 
												coldao.updateStat(colid, "0");
											}

											NodeList sublist=col.getElementsByTagName("SubItem");
											for(int j=0;j<sublist.getLength();j++)
											{
												Element subitem=(Element) sublist.item(j);
												String urlUrl= Util.strNotNull(subitem.getAttribute("url"));
												//filter the url:delet '#',"javascript",
												urlUrl = Util.BuildUrl(urlUrl, parurl, siteurl);
												if(urlUrl.length()==0)
													continue;


												String urlName=subitem.getTextContent();
												UrlAtt ua=new UrlAtt();
												ua.setJobId(job_id);
												ua.setName(urlName);
												ua.setUrl(Util.strNotNull(urlUrl));
												if(colid>0)
												{
													String uhash=AeSimpleSHA1.SHA1(ua.getUrl());
													int urlid=urldao.GetId(uhash);
													if(urlid>0){
														urldao.AddCol(urlid, colid);
													}else
													{
														if(!"".equals(ua.getUrl())){
															urlid=urldao.puttUrl(ua);
														}
														if(urlid>0){
															urldao.AddCol(urlid, colid);
														}	
													}
												}
											}
										}
									}
								}
								log.debug("col count:"+colCount);
								Integer tmpCount=uidMap.get(chl_id);
								if(tmpCount!=null)
								{
									tmpCount+=colCount;
									uidMap.put(chl_id, tmpCount);
								}
								else
								{
									uidMap.put(chl_id, colCount);
								}
							}
						}
						for(Map.Entry<Integer,Integer> ent:uidMap.entrySet())
						{
							log.debug("uid:"+ent.getKey());
							log.debug("count:"+ent.getValue());
							if(ent.getValue()>0)
							{
								chldao.updateStat(ent.getKey(), "2");
								chldao.resetFailCount(ent.getKey());
							}else{
								//set 9
								chldao.updateFailCount(ent.getKey());
								if(chldao.getFailCount(ent.getKey())>3){
									//错误超过3次，才更新成失败9
									chldao.resetFailCount(ent.getKey());
									chldao.updateStat(ent.getKey(), "9");
								}else{
									chldao.updateStat(ent.getKey(), "0");
								}

							}
						}
						taskdao.updateStatByTaskId(taskId, "2");
					}else{
						//无数据
						taskdao.updateStatByTaskId(taskId, "9");
						taskdao.updateRelationStatByTaskId(taskId, "9");
					}



				}else if(type.equals("2")){
					NodeList resultlist=docEle.getElementsByTagName("Result");
					if(resultlist.getLength()>0)
					{
						Map<Integer,Integer> uidMap=new HashMap<Integer,Integer>();
						//有数据
						for(int iresult=0;iresult<resultlist.getLength();iresult++)
						{
							Element colresult=(Element) resultlist.item(iresult);
							String url=colresult.getAttribute("url");
							String parurl=Util.GetUrlDir(url);
							String siteurl=Util.GetUrlSite(url);
							int col_id=Integer.parseInt(colresult.getAttribute("uid"));
							int job_id=coldao.getJobId(col_id);
							String error=colresult.getAttribute("error");
							if(error!=null&&error.length()>0)
							{
								//Document load error
								if(error.equals("5"))
								{
									coldao.updateStat(col_id, "9");
								}else
								{
									//Document load error
									coldao.updateFailCount(col_id);
									if(coldao.getFailCount(col_id)>3){
										//错误超过3次，才更新成2
										coldao.resetFailCount(col_id);
										coldao.updateStat(col_id, "2");	
									}else{
										coldao.updateStat(col_id, "0");
									}
								}
							}
							else
							{
								//column begin
								int itemCount=0;
								NodeList nl=colresult.getElementsByTagName("Column");
								if(nl.getLength()>0){
									Element col=(Element) nl.item(0);

									NodeList sublist=col.getElementsByTagName("SubItem");
									if(sublist.getLength()>0){
										//set 2
										for(int j=0;j<sublist.getLength();j++)
										{
											Element subitem=(Element) sublist.item(j);
											String urlUrl= Util.strNotNull(subitem.getAttribute("url"));
											//filter the url:delet '#',"javascript",

											urlUrl = Util.BuildUrl(urlUrl, parurl, siteurl);
											if(urlUrl.length()==0)
												continue;
											itemCount++;
											String urlName=subitem.getTextContent();
											UrlAtt ua=new UrlAtt();
											ua.setJobId(job_id);
											ua.setName(urlName);
											ua.setUrl(Util.strNotNull(urlUrl));

											if(col_id>0)
											{
												String hash=AeSimpleSHA1.SHA1(ua.getUrl());
												int urlid=urldao.GetId(hash);
												if(urlid>0){
													urldao.AddCol(urlid, col_id);
												}else{
													if(!"".equals(ua.getUrl())){
														urlid=urldao.puttUrl(ua);
													}
													if(urlid>0){
														urldao.AddCol(urlid, col_id);
													}	
												}
											}
										}
									}
								}
								Integer tmpCount=uidMap.get(col_id);
								if(tmpCount!=null)
								{
									tmpCount+=itemCount;
									uidMap.put(col_id, tmpCount);
								}
								else
								{
									uidMap.put(col_id, itemCount);
								}
							}
							//column end
						}
						for(Map.Entry<Integer,Integer> ent:uidMap.entrySet())
						{
							log.debug("uid:"+ent.getKey());
							log.debug("count:"+ent.getValue());
							if(ent.getValue()>0)
							{
								coldao.updateStat(ent.getKey(), "2");
								coldao.resetFailCount(ent.getKey());
							}else{
								//set 9
								coldao.updateFailCount(ent.getKey());
								if(coldao.getFailCount(ent.getKey())>3){
									//错误超过3次，才更新成失败9
									coldao.resetFailCount(ent.getKey());
									coldao.updateStat(ent.getKey(), "9");
								}else{
									coldao.updateStat(ent.getKey(), "0");
								}

							}
						}
						taskdao.updateStatByTaskId(taskId, "2");
					}else{
						//无数据
						taskdao.updateStatByTaskId(taskId, "9");	
						taskdao.updateRelationStatByTaskId(taskId, "9");
					}

				}else if(type.equals("3")){
					NodeList resultlist=docEle.getElementsByTagName("Result");
					if(resultlist.getLength()>0){
						Map<Integer,Integer> uidMap=new HashMap<Integer,Integer>();
						//有数据
						ArrayList<IdxAtt> idxList = new ArrayList<IdxAtt>(); 
						for(int iresult=0;iresult<resultlist.getLength();iresult++)
						{
							Element colresult=(Element) resultlist.item(iresult);
							String url=colresult.getAttribute("url");
							int url_id=Integer.parseInt(colresult.getAttribute("uid"));
							UrlAtt att=urldao.getUrl(url_id);
							String error=colresult.getAttribute("error");
							if(error!=null&&error.length()>0)
							{
								//Document load error
								if(error.equals("5"))
								{
									urldao.updateStat(url_id, "9");
								}else
								{
									//Document load error
									urldao.updateFailCount(url_id);
									if(urldao.getFailCount(url_id)>3){
										//错误超过3次，才更新成失败9
										urldao.resetFailCount(url_id);
										urldao.updateStat(url_id, "2");	
									}else{
										urldao.updateStat(url_id, "0");
									}
								}
							}else
							{
								//column begin
								int itemCount=0;

								NodeList nl=colresult.getElementsByTagName("Content");
								if(nl!=null && nl.getLength()>0)
								{
									//有ContentList
									IdxAtt ia=new IdxAtt();
									Element content=(Element) nl.item(0);
									ia.addAtts("#DREREFERENCE ", url);
									ia.setDbTitle(att.getName());
									JobAtt ja=jobdao.getJob(att.getJobId());
									List<Integer> colList=urldao.getColIds(url_id);
									NodeList contatts=content.getElementsByTagName("ContAtts");
									if(contatts!=null && contatts.getLength()>0)
									{

										Element contatt=(Element) nl.item(0);
										NodeList atts=contatt.getElementsByTagName("Att");
										for(int j=0;j<atts.getLength();j++)
										{
											Element attele=(Element)atts.item(j);
											String attName=attele.getAttribute("name");
											String attValue=attele.getTextContent();
											try{
												ia.addAtts(attName, attValue);
											}catch(Exception e){
												log.debug(e.toString());
											}
										}
									}


									for(Integer colId :colList)
									{
										//add column tag
										ColAtt colAtt = coldao.get(colId);
										ia.addAtts("#DREFIELD CHANNELNAME=", colAtt.getName());
									}


									ia.addAtts("#DREFIELD JOBNAME=", ja.getName());

									NodeList contentele=content.getElementsByTagName("Content");
									if(contentele!=null && contentele.getLength()>0)
									{
										//有内容的tag
										Element conele=(Element)contentele.item(0);
										String conStr = Util.strNotNull(conele.getTextContent());

										//判断长度
										if(conStr.length()>0){
											itemCount++;
											ia.setContent(conStr);
											idxList.add(ia);
										}
									}
								}
								Integer tmpCount=uidMap.get(url_id);
								if(tmpCount!=null)
								{
									tmpCount+=itemCount;
									uidMap.put(url_id, tmpCount);
								}
								else
									uidMap.put(url_id, itemCount);
							}
						}
						log.debug("send idx");
						try{
							idxdao.send(idxList);//索引内容POST
						}catch(Exception e){
							log.debug(e.toString());
						}
						for(Map.Entry<Integer,Integer> ent:uidMap.entrySet())
						{
							log.debug("uid:"+ent.getKey());
							log.debug("count:"+ent.getValue());
							if(ent.getValue()>0)
							{
								urldao.updateStat(ent.getKey(), "2");
								urldao.resetFailCount(ent.getKey());
							}else{
								//set 9
								urldao.updateFailCount(ent.getKey());
								if(urldao.getFailCount(ent.getKey())>3){
									//错误超过3次，才更新成失败9
									urldao.resetFailCount(ent.getKey());
									urldao.updateStat(ent.getKey(), "9");
								}else{
									urldao.updateStat(ent.getKey(), "0");
								}

							}
						}
						taskdao.updateStatByTaskId(taskId, "2");
					}else{
						//无数据
						log.debug("9999 begin");
						taskdao.updateStatByTaskId(taskId, "9");
						taskdao.updateRelationStatByTaskId(taskId, "9");
						log.debug("9999 end");
					}
				}
			}//end taskId>0
		} catch (ParserConfigurationException e) { 
			log.debug(e.getMessage()); 
		} catch (SAXException e) {

			log.debug(e.toString());
		} catch (IOException e) {

			log.debug(e.toString());
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			log.debug(e.toString());
		} 
		return true;
	}

	@Override
	public int getVersion(int id) {
		WrapAtt wrap=wrapdao.getWrap(id);
		return wrap.getVersion();
	}

	@Override
	public int addJob(String name, String url, String type, String comment) {
		JobAtt job=new JobAtt();
		job.setName(name);
		job.setSeed(url);
		job.setSeedType(type);
		job.setComment(comment);
		return jobdao.AddJob(job);
	}

	@Override
	public boolean updateJob(int id) {
		//9－》不变
		//2->0 即，从完成转成0
		boolean rtn = jobdao.updateJob(id);

		return rtn;
	}


	@Override
	public JobAtt getJob(int id) {
		return jobdao.getJob(id);
	}

	@Override
	public int[] getJobID() {
		List<JobAtt> joblist=jobdao.getAllJob();
		int [] ret=new int[joblist.size()];
		int i=0;
		for(JobAtt job:joblist)
		{
			ret[i]=job.getId();
			i++;
		}

		return ret;
	}

	@Override
	public JobAtt[] getJobs() {
		List<JobAtt> joblist=jobdao.getAllJob();
		JobAtt[]  ret=new JobAtt[joblist.size()];
		ret=joblist.toArray(new JobAtt[0]);
		return ret;
	}

	@Override
	public JobAtt[] getJobsWrapStatInvalid() {
		List<JobAtt> joblist=jobdao.getAllJobWrapInvalid();
		JobAtt[]  ret=new JobAtt[joblist.size()];
		ret=joblist.toArray(new JobAtt[0]);
		return ret;
	}

	@Override
	public boolean addWrapper(int jobId, String type, String Wrapper,String vargen,String comment) {
		log.debug(Wrapper+vargen+comment);

		WrapAtt wrap=new WrapAtt();
		wrap.setJobid(jobId);
		wrap.setType(type);
		wrap.setWrapper(Wrapper);
		wrap.setComment(comment);
		wrap.setVersion(1);
		wrap.setVargen(vargen);
		return wrapdao.putWrap(wrap)>0;
	}

	@Override
	public String getWrapGen(int id) {
		WrapAtt tmp=wrapdao.getWrap(id);
		return tmp.getVargen();
	}

	@Override
	public boolean updateWrapGen(String wrapgen, int id) {
		return wrapdao.updateWrapGen(wrapgen, id);
	}

	//	@Override
	//	public Task getTaskByJobId(int cid, int jid,String type,int num) {
	//		Task ret=null;
	//		WrapUrl wrapUrl = null;
	//		if("1".equals(type)){
	//			//channel
	//			List<ChlAtt> chls=chldao.getChls(jid,"0"); //取得chls
	//			List wraps = wrapdao.getWrapsByJob(jid, "1");
	//			if(wraps!=null && wraps.size()>0){
	//				WrapAtt wa=(WrapAtt)wraps.get(0);
	//				log.debug("chl wrap:"+wraps.size()+":"+wa.getId());
	//				wrapUrl = wrapUrl=new WrapUrl();
	//				wrapUrl.job_id=wa.getJobid();
	//				wrapUrl.type=wa.getType();
	//				wrapUrl.wrapid=wa.getId();
	//				wrapUrl.wrapver=wa.getVersion();
	//				wrapUrl.urlList = new ArrayList<UrlId>();
	//				for(ChlAtt  chl :chls)
	//				{
	//						chldao.updateStat(chl.getId(), "1");
	//						UrlId uid=new UrlId();
	//						uid.uid=chl.getId();
	//						uid.url=chl.getUrl();
	//	                    wrapUrl.urlList.add(uid);					
	//				}
	//			}
	//
	//		}else if("2".equals(type)){
	//			//column
	//			List<ColAtt> cols=coldao.getCols(jid,"0");
	//			List wraps = wrapdao.getWrapsByJob(jid, "2");
	//			
	//			if(wraps!=null && wraps.size()>0){
	//				WrapAtt wa=(WrapAtt)wraps.get(0);
	//				log.debug("cols wrap:"+wraps.size()+":"+wa.getId());
	//				wrapUrl = wrapUrl=new WrapUrl();
	//				wrapUrl.job_id=wa.getJobid();
	//				wrapUrl.type=wa.getType();
	//				wrapUrl.wrapid=wa.getId();
	//				wrapUrl.wrapver=wa.getVersion();
	//				wrapUrl.urlList = new ArrayList<UrlId>();				
	//				for(ColAtt  col :cols)
	//				{
	//					
	//					if(wraps.size()>0)
	//					{
	//						coldao.updateStat(col.getId(), "1");
	//						UrlId uid=new UrlId();
	//						uid.uid=col.getId();
	//						uid.url=col.getUrl();
	//						wrapUrl.urlList.add(uid);
	//					}
	//				}
	//			}
	//		}else if("3".equals(type)){
	//			//url
	//			List<UrlAtt> urlList=urldao.getUrls(jid,"0");
	//			List wraps=wrapdao.getWrapsByJob(jid, "3");
	//			if(wraps!=null && wraps.size()>0){
	//				WrapAtt wa=(WrapAtt)wraps.get(0);
	//				log.debug("cols wrap:"+wraps.size()+":"+wa.getId());
	//				wrapUrl = wrapUrl=new WrapUrl();
	//				wrapUrl.job_id=wa.getJobid();
	//				wrapUrl.type=wa.getType();
	//				wrapUrl.wrapid=wa.getId();
	//				wrapUrl.wrapver=wa.getVersion();
	//				wrapUrl.urlList = new ArrayList<UrlId>();				
	//				for(UrlAtt  url :urlList)
	//				{
	//					urldao.updateStat(url.getId(), "1");
	//					UrlId uid=new UrlId();
	//					uid.uid=url.getId();
	//					uid.url=url.getUrl();
	//					wrapUrl.urlList.add(uid);
	//				}
	//			}
	//		}else if("0".equals(type)){
	//			if(wrapUrl==null){
	//				List<ChlAtt> chls=chldao.getChls(jid,"0"); //取得chls
	//				List wraps = wrapdao.getWrapsByJob(jid, "1");
	//				if(wraps!=null && wraps.size()>0){
	//					WrapAtt wa=(WrapAtt)wraps.get(0);
	//					log.debug("chl wrap:"+wraps.size()+":"+wa.getId());
	//					wrapUrl = wrapUrl=new WrapUrl();
	//					wrapUrl.job_id=wa.getJobid();
	//					wrapUrl.type=wa.getType();
	//					wrapUrl.wrapid=wa.getId();
	//					wrapUrl.wrapver=wa.getVersion();
	//					wrapUrl.urlList = new ArrayList<UrlId>();
	//					for(ChlAtt  chl :chls)
	//					{
	//							chldao.updateStat(chl.getId(), "1");
	//							UrlId uid=new UrlId();
	//							uid.uid=chl.getId();
	//							uid.url=chl.getUrl();
	//		                    wrapUrl.urlList.add(uid);					
	//					}
	//				}
	//			}
	//			
	//			if(wrapUrl==null){
	//				List<ColAtt> cols=coldao.getCols(jid,"0");
	//				List wraps = wrapdao.getWrapsByJob(jid, "2");
	//				
	//				if(wraps!=null && wraps.size()>0){
	//					WrapAtt wa=(WrapAtt)wraps.get(0);
	//					log.debug("cols wrap:"+wraps.size()+":"+wa.getId());
	//					wrapUrl =new WrapUrl();
	//					wrapUrl.job_id=wa.getJobid();
	//					wrapUrl.type=wa.getType();
	//					wrapUrl.wrapid=wa.getId();
	//					wrapUrl.wrapver=wa.getVersion();
	//					wrapUrl.urlList = new ArrayList<UrlId>();				
	//					for(ColAtt  col :cols)
	//					{
	//						
	//						if(wraps.size()>0)
	//						{
	//							coldao.updateStat(col.getId(), "1");
	//							UrlId uid=new UrlId();
	//							uid.uid=col.getId();
	//							uid.url=col.getUrl();
	//							wrapUrl.urlList.add(uid);
	//						}
	//					}
	//				}
	//			}
	//			
	//			if(wrapUrl==null){
	//				List<UrlAtt> urlList=urldao.getUrls(jid,"0");
	//				List wraps=wrapdao.getWrapsByJob(jid, "3");
	//				if(wraps!=null && wraps.size()>0){
	//					WrapAtt wa=(WrapAtt)wraps.get(0);
	//					log.debug("cols wrap:"+wraps.size()+":"+wa.getId());
	//					wrapUrl = wrapUrl=new WrapUrl();
	//					wrapUrl.job_id=wa.getJobid();
	//					wrapUrl.type=wa.getType();
	//					wrapUrl.wrapid=wa.getId();
	//					wrapUrl.wrapver=wa.getVersion();
	//					wrapUrl.urlList = new ArrayList<UrlId>();				
	//					for(UrlAtt  url :urlList)
	//					{
	//						urldao.updateStat(url.getId(), "1");
	//						UrlId uid=new UrlId();
	//						uid.uid=url.getId();
	//						uid.url=url.getUrl();
	//						wrapUrl.urlList.add(uid);
	//					}
	//				}
	//			}
	//			
	//		}
	//		
	//		if(wrapUrl!=null)
	//		{
	//			ret=new Task();
	//			StringBuffer  tmp=new StringBuffer ();
	//
	////			for(int i=0;i<10 && wrapUrl.urlList.isEmpty();i++)
	////			{
	////				UrlId urlId = wrapUrl.urlList.poll();
	////				tmp.append(urlId.url);
	////				tmp.append("###");
	////				tmp.append(urlId.uid);
	////				tmp.append("####");
	////			}
	//			
	//			if(wrapUrl.urlList!=null){
	//				int i = 0;
	//				for(UrlId urlId :wrapUrl.urlList){
	//					if(i<num){
	//						tmp.append(urlId.url);
	//						tmp.append("###");
	//						tmp.append(urlId.uid);
	//						tmp.append("####");
	//					}else{
	//						break;
	//					}
	//					i++;
	//				}
	//			}
	//			//ret.setUrls(tmp.toString());
	//			ret.setUrls(tmp.toString());
	//			ret.setWrap_id(wrapUrl.wrapid);
	//			ret.setJob_id(wrapUrl.job_id);
	//			ret.setWrap_version(wrapUrl.wrapver);
	//			ret.setType(wrapUrl.type);
	//		}		
	//		return ret;
	//	}

	@Override
	public String test(String str) {
		// TODO Auto-generated method stub
		log.debug("ddddddddddddddddddddddddddddddd");
		return "######:"+str;
	}

	@Override
	public String test1(String str1, String str2) {
		// TODO Auto-generated method stub
		return "###$$$$$$$$$$$:"+str1+","+str2;
	}

	@Override
	public String test2(String str1, String str2,String str3) {
		// TODO Auto-generated method stub
		return "###$$$$$$$$$$$ccccccc:"+str1+","+str2+","+str3;
	}

	@Override
	public boolean hasTask(int cid) {
		// TODO Auto-generated method stub
		boolean ret = false;
		if(getTask(cid,1)!=null){
			ret = true;
		}
		return ret;
	}


	@Override
	public Task getTaskQueue(int num) {
		// TODO Auto-generated method stub
		Task ret=null;
		//channel
		if(ret == null){ 
			int jid = taskdao.getJobId("1","0");
			if(jid>0){
				ret = taskdao.getTaskQueueChannel(jid,"1",num,"0","-2");
			}
		}
		//column
		if(ret == null){ 
			int jid = taskdao.getJobId("2","0");
			if(jid>0){
				ret = taskdao.getTaskQueueColumn(jid,"2",num,"0","-2");
			}
		}
		//url
		if(ret == null){ 
			int jid = taskdao.getJobId("3","0");
			if(jid>0){
				ret = taskdao.getTaskQueueUrl(jid,"3",num,"0","-2");
			}
		}

		return ret;
	}


	@Override
	public Task getWrapTaskQueue(int num) {
		// TODO Auto-generated method stub
		Task ret=null;
		//channel
		if(ret == null){ 
			int jid = taskdao.getJobId("1","9");
			if(jid>0){
				ret = taskdao.getTaskQueueChannel(jid,"1",num,"9","-3");
			}
		}
		//column
		if(ret == null){ 
			int jid = taskdao.getJobId("2","9");
			if(jid>0){
				ret = taskdao.getTaskQueueColumn(jid,"2",num,"9","-3");
			}
		}
		//url
		if(ret == null){ 
			int jid = taskdao.getJobId("3","9");
			if(jid>0){
				ret = taskdao.getTaskQueueUrl(jid,"3",num,"9","-3");
			}
		}

		return ret;
	}	

	@Override
	public Task getTask(int cid,int num) {
		// TODO Auto-generated method stub
		Task ret=null;
		//task，先从task表冲取status=1的
		if(ret == null){ 
			int jid = taskdao.getJobIdFromTask(cid,"1");//from task_list
			//log.debug("jid:"+jid+" cid:"+cid);
			if(jid>0){
				ret = taskdao.getTask(cid,jid,"1");
			}
		}



		if(ret == null){
			ret = takeTask(cid);
		}

		//		//channel
		//		if(ret == null){ 
		//			int jid = taskdao.getJobId("1","0");
		//			if(jid>0){
		//				ret = taskdao.getTaskChannel(cid,jid,"1",num,"0","1");
		//			}
		//		}
		//		//column
		//		if(ret == null){ 
		//			int jid = taskdao.getJobId("2","0");
		//			if(jid>0){
		//				ret = taskdao.getTaskColumn(cid,jid,"2",num,"0","1");
		//			}
		//		}
		//		//url
		//		if(ret == null){ 
		//			int jid = taskdao.getJobId("3","0");
		//			if(jid>0){
		//				ret = taskdao.getTaskUrl(cid,jid,"3",num,"0","1");
		//			}
		//		}

		return ret;
	}

	@Override
	public Task getTaskByJobId(int cid, int jid,String type,int num) {
		//供抓取学习使用
		Task ret=null;

		//task，先从task表冲取status=10的
		if(ret == null){ 
			if(jid>0){
				ret = taskdao.getTask(cid,jid,"10");
			}
			log.debug("1111111111111");
		}

		if("1".equals(type)){
			//channel
			if(ret == null){ 
				if(jid>0){
					ret = taskdao.getTaskChannel(cid,jid,"1",num,"9","10");
				}
				log.debug("2222222");
			}
		}else if("2".equals(type)){
			//channel
			if(ret == null){ 
				if(jid>0){
					ret = taskdao.getTaskColumn(cid,jid,"2",num,"9","10");
				}
				log.debug("333333333");
			}		
		}else if("3".equals(type)){
			if(jid>0){
				ret = taskdao.getTaskUrl(cid,jid,"3",num,"9","10");
			}
			log.debug("4444");
		}
		return ret;
	}

	@Override
	public boolean delJob(int id) {
		// TODO Auto-generated method stub
		return jobdao.del(id)==1;
	}

	@Override
	public boolean updateJobUrl(int id,String url) {
		// TODO Auto-generated method stub
		return jobdao.updateJobUrl(id,url)==1;

	}

	@Override
	public Task getWrapInvalidTaskByJobId(int cid, int jid, String type, int num) {
		// TODO Auto-generated method stub
		Task ret=null;
		/*
		 * 供测试使用
		 */

		//task，先从task表冲取status=11的
		/*
		if(ret == null){ 
			if(jid>0){
				ret =  taskdao.getTask(cid,jid,type,"11");//type==0,则按照type＝＝1，2，3的顺序来取
			}
			log.debug("1111111111111");
		}
		 */


		if("1".equals(type)){
			//channel
			if(ret == null){
				if(jid>0){
					ret = taskdao.getTaskChannelWrapInvalid(cid,jid,"1",num);
				}
				log.debug("2222222");
			}
		}else if("2".equals(type)){
			//column
			if(ret == null){ 
				//最近的10条50％为9，才retun task，否则为null
				if(jid>0){
					ret = taskdao.getTaskColumnWrapInvalid(cid,jid,"2",num);
				}
				log.debug("333333333");
			}
		}else if("3".equals(type)){
			//url
			if(ret == null){ 
				//最近的20条50％为9，才retun task，否则为null
				if(jid>0){
					ret = taskdao.getTaskUrlWrapInvalid(cid,jid,"3",num);
				}
				log.debug("4444");
			}
		}
		//置成2，表示正在进行中,对task来说，2表示正在进行中
		//wrapdao.updateStatByWrapId(ret.getWrap_id(),"2");		

		return ret;

	}

	@Override
	public String add(String s) {
		// TODO Auto-generated method stub
		testq.add(s);
		return Util.str2int(s) +" now:"+testq.size();
	}

	@Override
	public String take() {
		// TODO Auto-generated method stub
		String rtn = "";
		try {
			if(testq.size()>0){
				rtn = "current:"+testq.take() +" now:"+testq.size();
			}else{
				//				   Thread pt = new Thread(new Crawler());
				//				   pt.start();				
				//				   rtn = "current:"+testq.take() +" now:"+testq.size();
			}


		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.debug(e.toString());
		}
		return rtn;
	}

	@Override
	public Task takeTask(int cid) {
		// TODO Auto-generated method stub
		Task rtn = null;
		try {
			if(Crawler.taskq.size()>0){
				rtn = Crawler.taskq.take();
				log.debug("taskq.size()>0");
				rtn = taskdao.takeTaskQueue(rtn,cid,"1");
			}else{
				//			   Thread pt = new Thread(new Crawler());
				//			   pt.start();				
				//			   rtn = Crawler.taskq.take();//"current:"+taskq.take() +" now:"+taskq.size();
				//			   rtn = taskdao.takeTaskQueue(rtn,cid,"1");

			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.debug(e.toString());
		}
		return rtn;
	}

	@Override
	public Task takeWrapTask(int cid) {
		// TODO Auto-generated method stub
		Task rtn = null;
		try {
			if(Crawler.wraptaskq.size()>0){
				rtn = Crawler.wraptaskq.take();
				rtn = taskdao.takeTaskQueue(rtn,cid,"10");
			}else{
				//			   Thread pt = new Thread(new Crawler());
				//			   pt.start();				
				//			   rtn = Crawler.wraptaskq.take();
				//			   rtn = taskdao.takeTaskQueue(rtn,cid,"10");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.debug(e.toString());
		}
		return rtn;
	}

	@Override
	public int[] getWrapId(int jid) {
		List<Integer> intList=wrapdao.getWrapId(jid);
		int [] ret=new int[intList.size()];
		int i=0;
		for(int id:intList)
		{
			ret[i]=id;
			i++;
		}
		return ret;
	}

	@Override
	public String getWraptype(int id) {
		return wrapdao.getWrapType(id);
	}




	//	public boolean putResultTest(String res, int cid) {
	//		// TODO Auto-generated method stub
	//		try { 
	//
	//			res = res.trim();
	//			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance(); 
	//			DocumentBuilder builder = factory.newDocumentBuilder();
	//			StringReader reader = new StringReader( res );
	//			InputSource inputSource = new InputSource( reader );
	//			inputSource.setEncoding("utf-8");
	//			Document document = builder.parse(inputSource);
	//			Element docEle=document.getDocumentElement();
	//
	//			int  taskId = Util.str2int(docEle.getAttribute("id"));
	//			String type= docEle.getAttribute("type");
	//			log.debug("type:"+type);
	//			log.debug("taskId:"+taskId);
	//			urldao.deleteall();
	//			if(taskId>0){
	//				if(type.equals("1")){
	//					//频道  
	//					NodeList resultlist=docEle.getElementsByTagName("Result");
	//					if(resultlist.getLength()>0){
	//						//有数据
	//						for(int iresult=0;iresult<resultlist.getLength();iresult++)
	//						{
	//							Element colresult=(Element) resultlist.item(iresult);
	//							String url=colresult.getAttribute("url");
	//							String parurl=url.substring(0,url.lastIndexOf('/')+1);
	//							NodeList nl=colresult.getElementsByTagName("Columns");
	//							if(nl.getLength()>0)
	//							{ 
	//								Element cols=(Element) nl.item(0);
	//								int chl_id=Integer.parseInt(cols.getAttribute("uid"));
	//								int job_id=chldao.getJobId(chl_id);
	//								NodeList collist=cols.getElementsByTagName("Column");
	//								if(collist.getLength()>0){
	//									//set 2
	//									for(int i=0;i<collist.getLength();i++)
	//									{
	//										Element col=(Element) collist.item(i);
	//										String colName= Util.strNotNull(col.getAttribute("name"));
	//										String colUrl= Util.strNotNull(col.getAttribute("url"));
	//										//filter the url:delet '#',"javascript",
	//										colUrl = colUrl.replaceAll("(#*)$", "");
	//										if(colUrl.length()==0||colUrl.indexOf("javascript:")>=0)
	//											continue;
	//										if(colUrl.indexOf("http://")!=0&&colUrl.indexOf("https://")!=0){
	//											colUrl=parurl+colUrl;
	//										}
	//										ColAtt cola=new ColAtt();
	//										cola.setChlId(chl_id);
	//										cola.setJobId(job_id);
	//										cola.setName(colName);//应该可以为null,数据库已经处理
	//										cola.setUrl(Util.strNotNull(colUrl));//不能为null
	//
	//										String hash=AeSimpleSHA1.SHA1(cola.getUrl());
	//										int colid=coldao.GetId(hash);
	//
	//										if(colid<=0 && !"".equals(cola.getUrl())){
	//											colid=coldao.puttCol(cola);
	//										}else{
	//											//栏目已经存在，更新状态为col_stat=0 
	//											coldao.updateStat(colid, "0");
	//										}
	//
	//										NodeList sublist=col.getElementsByTagName("SubItem");
	//										for(int j=0;j<sublist.getLength();j++)
	//										{
	//											Element subitem=(Element) sublist.item(j);
	//											String urlUrl= Util.strNotNull(subitem.getAttribute("url"));
	//											urlUrl = urlUrl.replaceAll("(#*)$", "");
	//											if(urlUrl.indexOf("http://")<0){
	//												urlUrl=parurl+urlUrl;
	//											}	
	//
	//
	//											String urlName=subitem.getTextContent();
	//											UrlAtt ua=new UrlAtt();
	//											ua.setJobId(job_id);
	//											ua.setName(urlName);
	//											ua.setUrl(Util.strNotNull(urlUrl));
	//											if(colid>0)
	//											{
	//												String uhash=AeSimpleSHA1.SHA1(ua.getUrl());
	//												int urlid=urldao.GetId(uhash);
	//												if(urlid>0){
	//													urldao.AddCol(urlid, colid);
	//												}else
	//												{
	//													if(!"".equals(ua.getUrl())){
	//														urlid=urldao.puttUrl(ua);
	//													}
	//													if(urlid>0){
	//														urldao.AddCol(urlid, colid);
	//													}	
	//												}
	//											}
	//										}
	//									}
	//									chldao.updateStat(chl_id, "2");
	//									chldao.resetFailCount(chl_id);
	//								}else{
	//									//set 9
	//									chldao.updateFailCount(chl_id);
	//									if(chldao.getFailCount(chl_id)>3){
	//										//错误超过3次，才更新成失败9
	//										chldao.resetFailCount(chl_id);
	//										chldao.updateStat(chl_id, "9");
	//									}else{
	//										chldao.updateStat(chl_id, "0");
	//									}
	//
	//								}
	//							}else
	//							{
	//								//return false;
	//							}
	//						}
	//						taskdao.updateStatByTaskId(taskId, "2");
	//					}else{
	//						//无数据
	//						taskdao.updateStatByTaskId(taskId, "9");
	//						taskdao.updateRelationStatByTaskId(taskId, "9");
	//					}
	//
	//
	//
	//				}else if(type.equals("2")){
	//
	//					NodeList resultlist=docEle.getElementsByTagName("Result");
	//					if(resultlist.getLength()>0){
	//						//有数据
	//						for(int iresult=0;iresult<resultlist.getLength();iresult++)
	//						{
	//							Element colresult=(Element) resultlist.item(iresult);
	//							String url=colresult.getAttribute("url");
	//							String parurl=url.substring(0,url.lastIndexOf('/')+1);
	//							//column begin
	//							NodeList nl=colresult.getElementsByTagName("Column");
	//							log.debug("nl.getLength:"+nl.getLength());
	//							if(nl.getLength()>0){
	//								Element col=(Element) nl.item(0);
	//								int col_id=Integer.parseInt(col.getAttribute("uid"));
	//								int job_id=coldao.getJobId(col_id);
	//								NodeList sublist=col.getElementsByTagName("SubItem");
	//								if(sublist.getLength()>0){
	//									//set 2
	//									for(int j=0;j<sublist.getLength();j++)
	//									{
	//										Element subitem=(Element) sublist.item(j);
	//										String urlUrl= Util.strNotNull(subitem.getAttribute("url"));
	//										//filter the url:delet '#',"javascript",
	//
	//										urlUrl = urlUrl.replaceAll("(#*)$", "");
	//
	//										if(urlUrl.length()==0||urlUrl.indexOf("javascript:")>=0)
	//											continue;
	//										if(urlUrl.indexOf("http://")!=0&&urlUrl.indexOf("https://")!=0){
	//											urlUrl=parurl+urlUrl;
	//										}
	//										String urlName=subitem.getTextContent();
	//										UrlAtt ua=new UrlAtt();
	//										ua.setJobId(job_id);
	//										ua.setName(urlName);
	//										ua.setUrl(Util.strNotNull(urlUrl));
	//
	//										if(col_id>0)
	//										{
	//											String hash=AeSimpleSHA1.SHA1(ua.getUrl());
	//											int urlid=urldao.GetId(hash);
	//											log.debug("uid=:"+urlid);
	//											if(urlid>0){
	//												urldao.AddCol(urlid, col_id);
	//											}else{
	//												if(!"".equals(ua.getUrl())){
	//													urlid=urldao.puttUrl(ua);
	//												}
	//												if(urlid>0){
	//													urldao.AddCol(urlid, col_id);
	//												}	
	//											}
	//										}
	//									}
	//									coldao.updateStat(col_id, "2");
	//									coldao.resetFailCount(col_id);
	//								}else{
	//									//set 9
	//									coldao.updateFailCount(col_id);
	//									if(coldao.getFailCount(col_id)>3){
	//										//错误超过3次，才更新成失败9
	//										coldao.resetFailCount(col_id);
	//										coldao.updateStat(col_id, "9");	
	//									}else{
	//										coldao.updateStat(col_id, "0");
	//									}									
	//								}
	//							}else{
	//								//return false;
	//							}
	//
	//							//column end
	//						}
	//						taskdao.updateStatByTaskId(taskId, "2");
	//					}else{
	//						//无数据
	//						taskdao.updateStatByTaskId(taskId, "9");	
	//						taskdao.updateRelationStatByTaskId(taskId, "9");
	//					}
	//
	//				}else if(type.equals("3")){
	//					NodeList resultlist=docEle.getElementsByTagName("Result");
	//					log.debug("before if");
	//					if(resultlist.getLength()>0){
	//						//有数据
	//						ArrayList<IdxAtt> idxList = new ArrayList<IdxAtt>(); 
	//						for(int iresult=0;iresult<resultlist.getLength();iresult++)
	//						{
	//							Element colresult=(Element) resultlist.item(iresult);
	//							String url=colresult.getAttribute("url");
	//							String parurl=url.substring(0,url.lastIndexOf('/')+1);
	//							//column begin
	//
	//							NodeList nl=colresult.getElementsByTagName("Content");
	//							if(nl!=null && nl.getLength()>0)
	//							{
	//								//有ContentList
	//								Element content=(Element) nl.item(0);
	//								IdxAtt ia=new IdxAtt();
	//								int url_id=Integer.parseInt(content.getAttribute("uid"));
	//								int job_id=urldao.getJobId(url_id);
	//								JobAtt ja=jobdao.getJob(job_id);
	//								List<Integer> colList=urldao.getColIds(url_id);
	//								HashMap<String,String> attMap=new HashMap<String,String>();
	//								NodeList contatts=content.getElementsByTagName("ContAtts");
	//								if(contatts!=null && contatts.getLength()>0)
	//								{
	//									Element contatt=(Element) nl.item(0);
	//									NodeList atts=contatt.getElementsByTagName("Att");
	//									for(int j=0;j<atts.getLength();j++)
	//									{
	//										Element attele=(Element)atts.item(j);
	//										String attName=attele.getAttribute("name");
	//										String attValue=attele.getTextContent();
	//										attMap.put(attName, attValue);
	//									}
	//								}
	//								attMap.put("#DREREFERENCE ", url);
	//								attMap.put("#DREFIELD JOBNAME=", ja.getName());
	//								NodeList contentele=content.getElementsByTagName("Content");
	//								if(contentele!=null && contentele.getLength()>0)
	//								{
	//									//有内容的tag
	//
	//									Element conele=(Element)contentele.item(0);
	//									String conStr = Util.strNotNull(conele.getTextContent());
	//
	//									//判断长度
	//									if(conStr.length()>0){
	//										//2
	//										urldao.updateStat(url_id, "2");
	//										urldao.resetFailCount(url_id);
	//										ia.setContent(conStr);
	//										idxList.add(ia);
	//									}else{
	//										//9
	//										urldao.updateFailCount(url_id);
	//										if(urldao.getFailCount(url_id)>3){
	//											//错误超过3次，才更新成失败9
	//											urldao.resetFailCount(url_id);
	//											urldao.updateStat(url_id, "9");	
	//										}else{
	//											urldao.updateStat(url_id, "0");
	//										}									
	//									}
	//
	//								}else{
	//									//无内容的tag
	//									urldao.updateFailCount(url_id);
	//									if(urldao.getFailCount(url_id)>3){
	//										//错误超过3次，才更新成失败9
	//										urldao.resetFailCount(url_id);
	//										urldao.updateStat(url_id, "9");	
	//									}else{
	//										urldao.updateStat(url_id, "0");
	//									}
	//								}//end if (contentele!=null && contentele.getLength()>0)
	//
	//
	//							}else
	//							{
	//								//没有ContentList
	//								//return false;
	//							}//end if if(nl!=null && nl.getLength()>0)
	//
	//							//idxdao.send(ia);
	//							//column end
	//						}
	//						idxdao.send(idxList);//索引内容POST
	//					}
	//					log.debug("22222222");
	//					taskdao.updateStatByTaskId(taskId, "2");
	//				}else{
	//					//无数据
	//					log.debug("9999 begin");
	//					taskdao.updateStatByTaskId(taskId, "9");
	//					taskdao.updateRelationStatByTaskId(taskId, "9");
	//					log.debug("9999 end");
	//				}
	//			}//end taskId>0
	//		} catch (ParserConfigurationException e) { 
	//			log.debug(e.getMessage()); 
	//		} catch (SAXException e) {
	//
	//			log.debug(e.toString());
	//		} catch (IOException e) {
	//
	//			log.debug(e.toString());
	//		} catch (NoSuchAlgorithmException e) {
	//			// TODO Auto-generated catch block
	//			log.debug(e.toString());
	//		} 
	//		return true;
	//	}

}
