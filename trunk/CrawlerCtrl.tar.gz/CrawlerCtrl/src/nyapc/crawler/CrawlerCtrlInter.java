package nyapc.crawler;
import javax.jws.WebService;

@WebService
public interface CrawlerCtrlInter extends CrawInter,WrapInter {
	//,Runnable

}
