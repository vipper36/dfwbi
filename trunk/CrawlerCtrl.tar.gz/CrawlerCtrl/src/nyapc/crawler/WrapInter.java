package nyapc.crawler;

public interface WrapInter {
	int getVersion(int id);
	String getWrapper(int id);
	String getWrapGen(int id);
	boolean updateWrapper(String wrap,int id,int taskid);
	boolean updateWrapperCheckOk(String wrap, int wrapId);
	boolean updateWrapGen(String wrapgen,int id);//保留接口，暂时保留
	Task getWrapTask(int cid,int num);
	Task getWrapTaskQueue(int num);
	int[] getWrapId(int jid);
	String getWraptype(int id);
	Task getWrapInvalidTask(int cid,int num);
	Task getWrapInvalidTaskByJobId(int cid,int jid,String type,int num);//clientid,jobid
	boolean addWrapper(int jobId,String type,String Wrapper,String vargen,String comment);
}
