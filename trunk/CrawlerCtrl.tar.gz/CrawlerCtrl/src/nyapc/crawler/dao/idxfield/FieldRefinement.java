package nyapc.crawler.dao.idxfield;

import com.apc.indextask.idx.Idx;

public interface FieldRefinement {

	public void refine(Idx idx);
	
}
