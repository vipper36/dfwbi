package nyapc.crawler.dao;

public class AttValue {
	public String name;
	public String value;
}
