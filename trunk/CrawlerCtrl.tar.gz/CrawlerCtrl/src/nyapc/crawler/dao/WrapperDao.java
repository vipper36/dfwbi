package nyapc.crawler.dao;
import java.util.List;

public interface WrapperDao {
	WrapAtt getWrap(int id);
	int putWrap(WrapAtt wrap);
	boolean updateWrap(String wrap, int id);
	boolean updateWrapGen(String wrapgen, int id);
	List getWrapsByJob(int jobid,String type);
	List listByStat(String stat);
	boolean updateStatByWrapId(int id,String stat);
	List getWrapId(int jid);
	String getWrapType(int id);
}
