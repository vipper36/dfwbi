package nyapc.crawler.dao;

import java.lang.reflect.Field;

/**
 * @author xt47442
 * 
 */
public abstract class AttSuperClass {
	public String toString() {
		// TODO Auto-generated method stub
		StringBuffer stb = new StringBuffer();
		try {
			Class c = this.getClass();
			Field f[] = c.getDeclaredFields();
			stb.append(c.getName() + " has " + f.length + " fields!" + "\n");
			for (int j = 0; j < f.length; j++) {
				f[j].setAccessible(true);
				String name = f[j].getName();
				if (f[j].get(this) != null) {
					stb.append("  ");
					stb.append(name + " --- {" + f[j].get(this) + "} \n");
				}
			}
		} catch (Throwable e) {
			System.err.println(e);
		}
		return stb.toString();
	}
}

