package nyapc.crawler.dao;

public class ChlAtt {
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getUrl() {
		return Url;
	}
	public void setUrl(String url) {
		Url = url;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getJobId() {
		return JobId;
	}
	public void setJobId(int jobId) {
		JobId = jobId;
	}

	
	private int Id;
	private String  Url;
	private String  Name;


	private int  JobId;
	

}
