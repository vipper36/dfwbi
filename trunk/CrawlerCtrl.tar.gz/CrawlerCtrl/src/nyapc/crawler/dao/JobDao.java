package nyapc.crawler.dao;

import java.util.List;

import nyapc.crawler.JobAtt;


public interface JobDao {
	boolean updateJob(int jid);
	JobAtt getJob(int jid);
	List getAllJob();
	List getAllJobWrapInvalid();
	int AddJob(JobAtt jod);
	int del(int id);
	int updateJobUrl(int jid,String url);
}
