package nyapc.crawler.test;


import java.io.IOException;
import java.io.StringReader;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import nyapc.crawler.CrawlerCtrl;
import nyapc.crawler.Task;
import nyapc.crawler.dao.AeSimpleSHA1;
import nyapc.crawler.dao.AgentAtt;
import nyapc.crawler.dao.AgentDao;
import nyapc.crawler.dao.ChlAtt;
import nyapc.crawler.dao.ChlDao;
import nyapc.crawler.dao.ColAtt;
import nyapc.crawler.dao.ColDao;
import nyapc.crawler.dao.TaskAtt;
import nyapc.crawler.dao.CrawlerDao;
import nyapc.crawler.dao.IdxAtt;
import nyapc.crawler.dao.IdxDao;
import nyapc.crawler.dao.JobDao;
import nyapc.crawler.dao.TaskDao;
import nyapc.crawler.dao.UrlAtt;
import nyapc.crawler.dao.UrlDao;
import nyapc.crawler.dao.WrapAtt;
import nyapc.crawler.dao.WrapperDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class TestCrawlerCtrl{
	private static Log log = LogFactory.getLog(TestCrawlerCtrl.class.getName());
	private ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
	private ChlDao chldao;
	private ColDao coldao;
	private UrlDao urldao;
	private WrapperDao wrapdao;
	private JobDao jobdao;
	private IdxDao idxdao;
	
	private AgentDao agentdao;
	private CrawlerDao crawlerdao;
	private TaskDao taskdao;
	
	public TestCrawlerCtrl()
    {
            chldao=(ChlDao)ctx.getBean("ChlDao");
            coldao=(ColDao)ctx.getBean("ColDao");
            urldao=(UrlDao)ctx.getBean("UrlDao");
            wrapdao=(WrapperDao)ctx.getBean("WrapDao");
            jobdao=(JobDao)ctx.getBean("JobDao");
            idxdao=(IdxDao)ctx.getBean("IdxDao");
            
            agentdao=(AgentDao)ctx.getBean("AgentDao");
            crawlerdao=(CrawlerDao)ctx.getBean("CrawlerDao");
            taskdao=(TaskDao)ctx.getBean("TaskDao");
            
            
            
    }

	public Task getWrapTask() {
		
		
		return null;
	}

	public static void main(String args[]) {
		//log.debug("task url:"+theTestTask.getTaskUrl());
		CrawlerCtrl theCrawlerCtrl = new CrawlerCtrl();
		String str = "";

		str +=" <?xml version=\"1.0\" encoding=\"UTF-8\"?><Task id=\"161444\"";
		str +=" type=\"2\">                                                                                    ";
		str +=" ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_21.htm\"><Column";
		str +=" uid=\"60575\"><SubItem url=\"content_147048.htm\">刘翔 你妈妈不准你找明星老";
		str +=" 婆</SubItem><SubItem url=\"content_147053.htm\">玩范儿</SubItem><SubItem";
		str +=" url=\"content_147056.htm\">奥运冠军掌舵川乒陈龙灿升任省乒羽中心副主任";
		str +=" </SubItem><SubItem url=\"content_147059.htm\">反赌球斗士先揭黑幕再诉足协";
		str +=" </SubItem><SubItem url=\"content_147060.htm\">张一：我和马琳不可能再成朋友";
		str +=" </SubItem><SubItem url=\"content_147063.htm\">希望四川足球重新雄起！";
		str +=" </SubItem><SubItem url=\"content_147065.htm\">1米97赵蕊蕊吓退相亲对象";
		str +=" </SubItem><SubItem url=\"content_147066.htm\">费德勒 差点遭了</SubItem>";
		str +=" <SubItem url=\"content_147067.htm\">雨水大风低温本该酷热季的澳网冷得离谱";
		str +=" </SubItem><SubItem url=\"content_147068.htm\">谢赫三连胜，获得千万韩元";
		str +=" </SubItem><SubItem url=\"content_147069.htm\">伍兹治完性瘾和虎嫂复合？";
		str +=" </SubItem><SubItem url=\"content_147070.htm\">广告</SubItem></Column></Result>            ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_41.htm\"><Column";
		str +=" uid=\"60576\"><SubItem url=\"content_147071.htm\">体彩开奖</SubItem><SubItem";
		str +=" url=\"content_147072.htm\">福利彩票</SubItem><SubItem";
		str +=" url=\"content_147073.htm\">抱娃躲过摄像头 “黑衣女子”到底是何方神圣？";
		str +=" </SubItem><SubItem url=\"content_147074.htm\">成都局部有零星小雨</SubItem>";
		str +=" <SubItem url=\"content_147075.htm\">公司不问责女财务被行政拘留5天";
		str +=" </SubItem><SubItem url=\"content_147076.htm\">停用特效药铊中毒护士收到12万";
		str +=" 捐款</SubItem><SubItem url=\"content_147077.htm\">广告</SubItem></Column></Result>                                                          ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_42.htm\"><Column";
		str +=" uid=\"60577\"><SubItem url=\"content_147078.htm\">这群“侦探”不破案 只找成都";
		str +=" 古建筑</SubItem><SubItem url=\"content_147080.htm\">成都去年处级以上领导落";
		str +=" 马30人</SubItem><SubItem url=\"content_147082.htm\">驾校承诺：安排学员完成";
		str +=" 学业</SubItem><SubItem url=\"content_147083.htm\">无照驾摩托撞伤人负全责被";
		str +=" 刑拘</SubItem><SubItem url=\"content_147084.htm\">少女来川见网友父亲打飞的";
		str +=" 接她</SubItem><SubItem url=\"content_147086.htm\">抓住盗车嫌疑人“追车神探”";
		str +=" 受伤</SubItem><SubItem url=\"content_147089.htm\">爱情斑马线上女士被车碾伤";
		str +=" 双脚</SubItem><SubItem url=\"content_147090.htm\">揣着刀片中年女子醉卧学校";
		str +=" 外</SubItem><SubItem url=\"content_147093.htm\">睡眠是金，睡眠是福";
		str +=" </SubItem><SubItem url=\"content_147095.htm\">广告</SubItem></Column></Result>                                                                                                                                      ";
		str +=" ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_43.htm\"><Column";
		str +=" uid=\"60578\"><SubItem url=\"content_147079.htm\">嫌陪伴时间不够 “干亲家”掐";
		str +=" 死女情人</SubItem><SubItem url=\"content_147081.htm\">看老虎没错逗老虎发威";
		str +=" 就是你不对了</SubItem><SubItem url=\"content_147085.htm\">蛇盘路中吓路人消";
		str +=" 防用钩 子捉走</SubItem><SubItem url=\"content_147087.htm\">卷帘门带电商家";
		str +=" 手裹胶带开门</SubItem><SubItem url=\"content_147088.htm\">你“买一斤送半斤”";
		str +=" 我“买一斤送一斤”</SubItem><SubItem url=\"content_147092.htm\">每天坐车1小";
		str +=" 时他给患癌妻送鸡汤</SubItem><SubItem url=\"content_147094.htm\">停在路边1";
		str +=" 年多奥拓车无人认领</SubItem><SubItem url=\"content_147096.htm\">女子楼顶扔";
		str +=" 杂物民警苦言劝下</SubItem><SubItem url=\"content_147097.htm\">开套牌出租撞";
		str +=" 伤交警 司机被刑拘</SubItem><SubItem url=\"content_147098.htm\">手机误报SOS";
		str +=" 妈妈走失虚惊一场</SubItem><SubItem url=\"content_147099.htm\">站前警方逮捕";
		str +=" 16名嫌疑人</SubItem><SubItem url=\"content_147100.htm\">民警装成赌客打掉藏";
		str +=" 枪的地下赌场</SubItem><SubItem url=\"content_147101.htm\">广告</SubItem>";
		str +=" </Column></Result>                                                          ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_44.htm\"><Column";
		str +=" uid=\"60579\"><SubItem url=\"content_147091.htm\">广告</SubItem></Column></Result>                                                                                                                                                ";
		str +=" ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_45.htm\"><Column";
		str +=" uid=\"60580\"><SubItem url=\"content_146962.htm\">百度一下 我买的车是个退";
		str +=" 货？</SubItem><SubItem url=\"content_146964.htm\">李庄古镇有了志愿消防队";
		str +=" </SubItem><SubItem url=\"content_146966.htm\">广告未审批医院面临最高10万处";
		str +=" 罚</SubItem><SubItem url=\"content_146968.htm\">街上捡到3900元是赌徒撒下";
		str +=" 的？</SubItem><SubItem url=\"content_146972.htm\">追薪一年追回万血汗钱";
		str +=" </SubItem><SubItem url=\"content_146976.htm\">一镜三“枪”轻松应对痔疮";
		str +=" </SubItem><SubItem url=\"content_146982.htm\">广告</SubItem></Column></Result>                                          ";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_46.htm\"><Column";
		str +=" uid=\"60581\"><SubItem url=\"content_146963.htm\">终审南充“黑老大”还是死刑";
		str +=" </SubItem><SubItem url=\"content_146965.htm\">酒后开车撞死人 找人顶包露了";
		str +=" 馅</SubItem><SubItem url=\"content_146967.htm\">白墙黛瓦居民住进“生土房”";
		str +=" </SubItem><SubItem url=\"content_146971.htm\">揭开内江车祸“死者消失两小时";
		str +=" 之谜”</SubItem><SubItem url=\"content_146974.htm\">年关临近竹海腊肉卖得俏";
		str +=" </SubItem><SubItem url=\"content_146978.htm\">姐弟婚外恋酿苦果</SubItem>";
		str +=" <SubItem url=\"content_146981.htm\">广告</SubItem></Column></Result>";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_47.htm\"><Column";
		str +=" uid=\"60582\"><SubItem url=\"content_146969.htm\">股指期货什么样中金所征求意";
		str +=" 见</SubItem><SubItem url=\"content_146970.htm\">“皖江规划”刺激安徽板块乘势";
		str +=" 崛起</SubItem><SubItem url=\"content_146975.htm\">八股创业板上市机构预测平";
		str +=" 均涨幅24%</SubItem><SubItem url=\"content_146979.htm\">股指期货再一次暴富";
		str +=" 盛宴</SubItem><SubItem url=\"content_146984.htm\">上市公司2009年业绩预告";
		str +=" </SubItem><SubItem url=\"content_146987.htm\">广告</SubItem></Column></Result>";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_48.htm\"><Column";
		str +=" uid=\"60583\"><SubItem url=\"content_146973.htm\">震荡盘升期待突破</SubItem>";
		str +=" <SubItem url=\"content_146977.htm\">万家精选首次分红</SubItem><SubItem";
		str +=" url=\"content_146980.htm\">短线股指酝酿方向选择</SubItem><SubItem";
		str +=" url=\"content_146983.htm\">股神与抄底</SubItem><SubItem";
		str +=" url=\"content_146985.htm\">北斗星通可能带动科技股狂飙</SubItem><SubItem";
		str +=" url=\"content_146986.htm\">热点似乎有转向迹象</SubItem><SubItem";
		str +=" url=\"content_146988.htm\">栋梁新材跌停年报行情依旧</SubItem><SubItem";
		str +=" url=\"content_146989.htm\">A股开户数回升逾两成持仓账户数逼近新高</SubItem>";
		str +=" </Column></Result>";
		str +=" <Result";
		str +=" url=\"http://wccdaily.scol.com.cn/epaper/hxdsb/html/2010-01/20/node_49.htm\"><Column";
		str +=" uid=\"60584\"><SubItem url=\"content_146990.htm\">中国超级智库首发“世情报告”";
		str +=" </SubItem><SubItem url=\"content_146991.htm\">2009年国企利润增速同比由负转";
		str +=" 正</SubItem><SubItem url=\"content_146992.htm\">1年期央票利率再涨8.3个基点";
		str +=" </SubItem><SubItem url=\"content_146993.htm\">去年人民币有效汇率贬值6.1%";
		str +=" </SubItem><SubItem url=\"content_146994.htm\">国开行2009年实现净利润302亿";
		str +=" 元</SubItem><SubItem url=\"content_146995.htm\">发改委：石油对外依存度达";
		str +=" 52%</SubItem><SubItem url=\"content_146996.htm\">成都国税地税收入创历史新";
		str +=" 高</SubItem><SubItem url=\"content_146997.htm\">监管部门按季控制信贷";
		str +=" </SubItem><SubItem url=\"content_146998.htm\">去年四川人均“吃”掉1311元";
		str +=" </SubItem><SubItem url=\"content_146999.htm\">成都将建全球最大二手车流通平";
		str +=" 台</SubItem><SubItem url=\"content_147001.htm\">广告</SubItem></Column> </Result></Task>";


		int cid = 1;
		
		
		
		log.debug(str);
		
//		for(int i=0;i<1000;i++){
//		   theCrawlerCtrl.putResultTest(str, cid);
//		   try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		}
	}


}
