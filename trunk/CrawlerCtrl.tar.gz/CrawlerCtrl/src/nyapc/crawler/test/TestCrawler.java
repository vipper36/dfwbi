package nyapc.crawler.test;


import java.io.IOException;
import java.io.StringReader;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import nyapc.crawler.Task;
import nyapc.crawler.dao.AeSimpleSHA1;
import nyapc.crawler.dao.AgentAtt;
import nyapc.crawler.dao.AgentDao;
import nyapc.crawler.dao.ChlAtt;
import nyapc.crawler.dao.ChlDao;
import nyapc.crawler.dao.ColAtt;
import nyapc.crawler.dao.ColDao;
import nyapc.crawler.dao.CrawlerAtt;
import nyapc.crawler.dao.CrawlerDao;
import nyapc.crawler.dao.IdxAtt;
import nyapc.crawler.dao.IdxDao;
import nyapc.crawler.dao.JobDao;
import nyapc.crawler.dao.TaskDao;
import nyapc.crawler.dao.UrlAtt;
import nyapc.crawler.dao.UrlDao;
import nyapc.crawler.dao.WrapAtt;
import nyapc.crawler.dao.WrapperDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class TestCrawler{
	private static Log log = LogFactory.getLog(TestCrawler.class.getName());
	private ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
	private ChlDao chldao;
	private ColDao coldao;
	private UrlDao urldao;
	private WrapperDao wrapdao;
	private JobDao jobdao;
	private IdxDao idxdao;
	
	private AgentDao agentdao;
	private CrawlerDao crawlerdao;
	private TaskDao taskdao;
	
	public TestCrawler()
    {
            chldao=(ChlDao)ctx.getBean("ChlDao");
            coldao=(ColDao)ctx.getBean("ColDao");
            urldao=(UrlDao)ctx.getBean("UrlDao");
            wrapdao=(WrapperDao)ctx.getBean("WrapDao");
            jobdao=(JobDao)ctx.getBean("JobDao");
            idxdao=(IdxDao)ctx.getBean("IdxDao");
            
            agentdao=(AgentDao)ctx.getBean("AgentDao");
            crawlerdao=(CrawlerDao)ctx.getBean("CrawlerDao");
            taskdao=(TaskDao)ctx.getBean("TaskDao");
            
            
            
    }

	public Task getWrapTask() {
		
		
		return null;
	}

	public static void main(String args[]) {
		TestCrawler theTestCrawler = new TestCrawler();
		
		//theTestCrawler.addCrawler();
		log.debug("get:"+theTestCrawler.getCrawler(2));
		CrawlerAtt theCrawlerAtt = theTestCrawler.getCrawler(2);
		theCrawlerAtt.setCrawlerStatus(2);
		theTestCrawler.updateCrawler(theCrawlerAtt);
		
		log.debug("get:"+theTestCrawler.getCrawler(2));
//		log.debug("list:"+theTestCrawler.getList());
//		log.debug("ddd");
	}

	public void addCrawler() {
		
		CrawlerAtt theCrawlerAtt = new CrawlerAtt();
        theCrawlerAtt.setCrawlerName("9999999999999");
        crawlerdao.save(theCrawlerAtt);
	}

	public void updateCrawler(CrawlerAtt theCrawlerAtt ) {
		
        crawlerdao.save(theCrawlerAtt);
	}
	
	public CrawlerAtt getCrawler(int id) {
		
       return crawlerdao.get(id);
		
        
	}
	
	
	public List getList() {
	       return crawlerdao.list();
	}	
	
}
