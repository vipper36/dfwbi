package nyapc.crawler.test;

import nyapc.crawler.dao.ChlDaoImp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Test {

	private static Log log = LogFactory.getLog(Test.class.getName());
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String[] strArray = new String[]{"dd","cc"};
        for(String str : strArray){
        	log.debug(str);
        }
        
	}

}
