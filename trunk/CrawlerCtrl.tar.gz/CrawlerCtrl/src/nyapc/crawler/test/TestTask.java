package nyapc.crawler.test;


import java.io.IOException;
import java.io.StringReader;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

import javax.jws.WebService;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import nyapc.crawler.Task;
import nyapc.crawler.Util;
import nyapc.crawler.dao.AeSimpleSHA1;
import nyapc.crawler.dao.AgentAtt;
import nyapc.crawler.dao.AgentDao;
import nyapc.crawler.dao.ChlAtt;
import nyapc.crawler.dao.ChlDao;
import nyapc.crawler.dao.ColAtt;
import nyapc.crawler.dao.ColDao;
import nyapc.crawler.dao.TaskAtt;
import nyapc.crawler.dao.CrawlerDao;
import nyapc.crawler.dao.IdxAtt;
import nyapc.crawler.dao.IdxDao;
import nyapc.crawler.dao.JobDao;
import nyapc.crawler.dao.TaskDao;
import nyapc.crawler.dao.UrlAtt;
import nyapc.crawler.dao.UrlDao;
import nyapc.crawler.dao.WrapAtt;
import nyapc.crawler.dao.WrapperDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class TestTask{
	private static Log log = LogFactory.getLog(TestTask.class.getName());
	private ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
	private ChlDao chldao;
	private ColDao coldao;
	private UrlDao urldao;
	private WrapperDao wrapdao;
	private JobDao jobdao;
	private IdxDao idxdao;
	
	private AgentDao agentdao;
	private CrawlerDao crawlerdao;
	private TaskDao taskdao;
	
	public TestTask()
    {
            chldao=(ChlDao)ctx.getBean("ChlDao");
            coldao=(ColDao)ctx.getBean("ColDao");
            urldao=(UrlDao)ctx.getBean("UrlDao");
            wrapdao=(WrapperDao)ctx.getBean("WrapDao");
            jobdao=(JobDao)ctx.getBean("JobDao");
            idxdao=(IdxDao)ctx.getBean("IdxDao");
            
            agentdao=(AgentDao)ctx.getBean("AgentDao");
            crawlerdao=(CrawlerDao)ctx.getBean("CrawlerDao");
            taskdao=(TaskDao)ctx.getBean("TaskDao");
            
    }

	public Task getWrapTask() {
		
		
		return null;
	}

	public static void main(String args[]) {
		TestTask theTestTask = new TestTask();
		
//		theTestTask.addTask();
//		log.debug("get:"+theTestTask.getTask(4));
//		TaskAtt theTaskAtt = theTestTask.getTask(4);
//		theTaskAtt.setTaskStatus(1);
//		theTestTask.updateTask(theTaskAtt);
//		
//		log.debug("get:"+theTestTask.getTask(4));
//		log.debug("list:"+theTestTask.getList());
//		log.debug("ddd");
//		
//		log.debug("list:"+theTestTask.getRole());
		
		//log.debug("task channel:"+theTestTask.getTaskChannel());
		//log.debug("task column:"+theTestTask.getTaskColumn());
		theTestTask.update();
		
		//log.debug("task url:"+theTestTask.getTaskUrl());
	    

	}

	public void addTask() {
		
		TaskAtt theTaskAtt = new TaskAtt();
        //theTaskAtt.setRelationId(99);
        taskdao.save(theTaskAtt);
	}

	public void updateTask(TaskAtt theTaskAtt ) {
		
		taskdao.save(theTaskAtt);
	}
	
	public TaskAtt getTask(int id) {
		
       return taskdao.get(id);
		
        
	}
	
	
	public List getList() {
	       return taskdao.list();
	}	
	

	public Task getTaskChannel() {
	   return taskdao.getTaskChannel(1,192,"1",2,"0","1");
	}
	
	public Task getTaskColumn() {
		return taskdao.getTaskColumn(1,810,"2",2,"0","1");
	}

	public Task getTaskUrl() {
		return taskdao.getTaskUrl(1,192,"3",2,"0","1");
	}

	public void update(){
		taskdao.updateRelationStatByTaskId(3778, "9");
	}
}
