package nyapc.crawler.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import nyapc.crawler.CrawlerCtrl;
import nyapc.crawler.JobAtt;
import nyapc.crawler.Task;
import nyapc.crawler.dao.AgentAtt;
import junit.framework.Assert;
import junit.framework.TestCase;

public class chlTest extends TestCase {
	private static Log log = LogFactory.getLog(chlTest.class.getName());
	private CrawlerCtrl chli;
	public chlTest()
	{
		chli=new CrawlerCtrl();
	}
	 public void testChl1() {  
		log.debug("start test");
		assertNotNull(chli);

	 }
	 public void testGetWrapeer()
	 {
		 
		 String wrap=chli.getWrapper(23);
		 assertNotNull(wrap);
		 log.debug("wrap:"+wrap);
	 }
	 
	 public void testGetJOB()
	 {
		 int[] jobs=chli.getJobID();
		 Assert.assertTrue(jobs.length>0);
		 for(int job:jobs)
		 {
			 log.debug("id:"+job);
			 JobAtt tmp=chli.getJob(job);
			 assertNotNull(tmp);
			 log.debug("name:"+tmp.getName());
		 }
	 }
	 public void testUpdateJOB()
	 {

		assertNotNull(chli.updateJob(163));
//		assertNotNull(chli.updateJob(101));
	//	assertNotNull(chli.updateJob(102));

	 }
	 public void testGetTask()
	 {
		 Task task=chli.getTask(1,10);
		 log.debug(task.getWrap_id()+task.getUrls());
		assertNotNull(task.getJob_id()>0);
//		task=chli.getTask(1);
//		log.debug(task.getWrap_id()+task.getUrls()[0].getUrl());
//		assertNotNull(task.getJob_id()>0);
//		task=chli.getTask(1);
//		log.debug(task.getWrap_id()+task.getUrls()[0].getUrl());
//		assertNotNull(task.getJob_id()>0);
	 }
	 public void testaddWrapper()
	 {
		 
		assertNotNull(chli.addWrapper(131, "2", "111","", ""));
	 }
	 public void testupdateWrapper()
	 {
		 
		assertNotNull(chli.updateWrapper("1231231", 2865,2545));
	 }
	 public void testAgentAddWrapper()
	 {
		
		 AgentAtt theAgentAtt = new AgentAtt();
		 
		assertNotNull(chli.addWrapper(131, "2", "111","", ""));
	 }	 
	 public void testGetTaskByJobID()
	 {
		 
		assertNotNull(chli.getTaskByJobId(1, 2506, "2",5));
	 }
	 public void testgetWrapID()
	 {
		int [] ids=chli.getWrapId(3709);
		assertNotNull(ids);
		System.out.println(ids.length);
		
	 }
}
