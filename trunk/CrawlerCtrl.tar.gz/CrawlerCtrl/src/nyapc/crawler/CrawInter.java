package nyapc.crawler;

import nyapc.crawler.dao.TaskAtt;


public interface CrawInter {
	Task getTaskQueue(int num);//for queue
	Task getTask(int cid,int num);//clientid
	Task getTaskByJobId(int cid,int jid,String type,int num);//clientid,jobid
	
	
	
	boolean putResult(String res,int cid);
	int getStat(int cid);
	int addJob(String name,String url,String type,String comment);
	boolean delJob(int id);
	
	int [] getJobID();
	JobAtt getJob(int id);
	JobAtt[] getJobs();
	JobAtt[] getJobsWrapStatInvalid();
	boolean updateJob(int id);
	boolean updateJobUrl(int id,String url);
	String test(String str);
	String test1(String str1,String str2);
	String test2(String str1,String str2,String str3);
	boolean hasTask(int cid);
	
	
	String add(String s);
	String take();
	
	Task takeTask(int cid);
	Task takeWrapTask(int cid);
	
	
	
}
