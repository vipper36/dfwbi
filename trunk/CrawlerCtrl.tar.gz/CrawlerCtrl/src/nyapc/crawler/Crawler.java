package nyapc.crawler;

import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Crawler implements Runnable {
	private static Log log = LogFactory.getLog(CrawlerCtrl.class.getName());
	public static BlockingQueue<Task> taskq = new LinkedBlockingDeque<Task>();
	public static BlockingQueue<Task> wraptaskq = new LinkedBlockingDeque<Task>();
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while (!Thread.interrupted()){
			    try {
			    	if(taskq.size()<=100){
			    		CrawlerCtrl theCrawlerCtrl = new CrawlerCtrl();
				    	for(int i=0;i<60;i++){
				    		Task task = theCrawlerCtrl.getTaskQueue(10);
				    		if(task !=null){
				    			taskq.add(task);
				    		}
				    	}
				    	
			    	}else{
			    		//null
			    	}	  
			    	
			    	if(wraptaskq.size()<=20){
			    		CrawlerCtrl theCrawlerCtrl = new CrawlerCtrl();
				    	for(int i=0;i<10;i++){
				    		Task task = theCrawlerCtrl.getWrapTaskQueue(10);
				    		if(task !=null){
				    			wraptaskq.add(task);
				    		}		    		
				    	}
			    	}else{
			    		//null
			    	}	    	
			    	
			    	
			     //log.debug("生产：dd"  );
			     Thread.sleep(1000*30);
			     //TimeUnit.MILLISECONDS.sleep(1000*30);
			    } catch (Exception e) {
			        log.debug(e.toString());
			    }
		}

	}

}
