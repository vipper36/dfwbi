/usr/local/xulrunner-sdk/bin/run-mozilla.sh /usr/local/xulrunner-sdk/bin/xpcshell Crawler.js
