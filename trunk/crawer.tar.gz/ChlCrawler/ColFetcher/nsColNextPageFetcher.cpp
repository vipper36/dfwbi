#include "nsIServiceManager.h"
#include "nsIGenericFactory.h"
#include "nsNetUtil.h"
#include "nsIUrlAtt.h"
#include "nsIDOMHTMLDocument.h"
#include "nsIDOMHTMLCollection.h"
#include "nsColNextPageFetcher.h"
#include <iostream>
#include <sstream>
#include <map>
#include <list>
#include <stack>
#include <vector>
#include "nsIDOM3Node.h"
#include "nsIDOMHTMLAnchorElement.h"
#include "nsIDOMHTMLLinkElement.h"
#include "mozIJSSubScriptLoader.h"
#include "nsIDOMDocumentEvent.h"
#include "nsIDOMEvent.h"
#include "nsIColAtt.h"
#include "sha1.h"
#include "property.h"
#include <regex.h>
#include <stdlib.h>
static NS_DEFINE_CID(kIOServiceCID, NS_IOSERVICE_CID);
NS_IMPL_ISUPPORTS1(nsColNextPageFetcher, nsIColNextPageFetcher)

NS_GENERIC_FACTORY_CONSTRUCTOR(nsColNextPageFetcher)

static nsModuleComponentInfo components[] =
{
     {
	  NS_COLNEXTPAGEFETCHER_CLASSNAME,
	  NS_COLNEXTPAGEFETCHER_CID,
	  NS_COLNEXTPAGEFETCHER_CONTRACTID,
	  nsColNextPageFetcherConstructor,
     }
};
NS_IMPL_NSGETMODULE("nsColNextPageFetcherModule", components)


/* Implementation file */

nsColNextPageFetcher::nsColNextPageFetcher()
:hasLoadJs(false),
     mNextPage(nsnull)
{
     /* member initializers and constructor code */
}

nsColNextPageFetcher::~nsColNextPageFetcher()
{
     /* destructor code */
}

/* attribute nsIColAtt col; */
NS_IMETHODIMP nsColNextPageFetcher::GetCol(nsIColAtt * *aCol)
{
     *aCol=mCol;
     NS_ADDREF(*aCol);
     return NS_OK;
}
NS_IMETHODIMP nsColNextPageFetcher::SetCol(nsIColAtt * aCol)
{
     mCol=aCol;
     return NS_OK;
}

/* void SetDocument (in nsIDOMDocument doc); */
NS_IMETHODIMP nsColNextPageFetcher::SetDocument(nsIDOMDocument *doc)
{
     mDoc=doc;
     mNextPage=nsnull;
     mEvtEle=nsnull;
     pages.Clear();
     FillPages();
     return NS_OK;
}

/* void SetProperty (in nsIPersistentProperties prop); */
NS_IMETHODIMP nsColNextPageFetcher::SetProperty(nsIPersistentProperties *prop)
{
     property=prop;


     return NS_OK;
}
/* attribute nsIColAtt nextPage; */
NS_IMETHODIMP nsColNextPageFetcher::GetNextPage(nsIColAtt * *aNextPage)
{
     if(mNextPage!=nsnull)
     {
	  *aNextPage=mNextPage;
	  NS_ADDREF(*aNextPage);
     }
     return NS_OK;
}
/* void GetEventEle (out nsIDOMElement ele); */
NS_IMETHODIMP nsColNextPageFetcher::GetEventEle(nsIDOMElement **ele)
{
     if(mEvtEle!=nsnull)
     {
	  *ele=mEvtEle;
	  NS_ADDREF(*ele);
     }
     return NS_OK;
}
/** 
 * @brief Get the urls on the other page or Get the next page url and create a new Colum. 
 * 
 * 
 * @return 
 */
NS_IMETHODIMP nsColNextPageFetcher::FillPages()
{
     nsCOMPtr<nsIDOMElement> domele;
     mDoc->GetDocumentElement(getter_AddRefs(domele));
     nsIDOMNode *domnode;
     CallQueryInterface(domele,&domnode);
     std::list<nsIDOMNode*> leafList;
     std::stack<nsIDOMNode*> eleStack;
     eleStack.push(domnode);
     while(!eleStack.empty())
     {
	  nsIDOMNode *domele=eleStack.top();
	  eleStack.pop();
	  nsCOMPtr<nsIDOMElement> tmpEle=do_QueryInterface(domele);
	  bool isLeaf=true;
	  domnode=nsnull;
	  for(domele->GetFirstChild(&domnode);domnode!=nsnull;domnode->GetNextSibling(&domnode))
	  {
	       PRUint16 type;
	       domnode->GetNodeType(&type);
	       if(type==nsIDOMNode::ELEMENT_NODE)
	       {
		    isLeaf=false;
		    break;
	       }
	  }
	  if(isLeaf)
	       leafList.push_back(domele);
	  else
	  {
	       domnode=nsnull;
	       for(domele->GetFirstChild(&domnode);domnode!=nsnull;domnode->GetNextSibling(&domnode))
	       {
		    PRUint16 type;
		    domnode->GetNodeType(&type);
		    if(type==nsIDOMNode::ELEMENT_NODE)
		    {
			 eleStack.push(domnode);
		    }
	       }
	  }
     }
     std::list< std::list<std::string> > UrlClass;
     bool getNextPage=false;
     for(std::list<nsIDOMNode*>::iterator it=leafList.begin();it!=leafList.end();++it)
     {
	  nsCOMPtr<nsIDOMElement> tmpEle=do_QueryInterface(*it);
	  
	  nsString Text;
	  nsCOMPtr<nsIDOM3Node> nsEle=do_QueryInterface(tmpEle);
	  nsEle->GetTextContent(Text);
	  std::string eleTextStr(NS_ConvertUTF16toUTF8(Text).get());
	  LOG<<"title:"<<eleTextStr<<"\n";

	  nsString linkUrl;
	  nsCOMPtr<nsIDOMHTMLAnchorElement> linkEle=do_QueryInterface(tmpEle);
	  if(linkEle!=nsnull)
	  {
	       linkEle->GetHref(linkUrl);
	  }else
	  {
	       nsCOMPtr<nsIDOMHTMLLinkElement>  linkEle2=do_QueryInterface(tmpEle);
	       if(linkEle2!=nsnull)
	       {
		    linkEle2->GetHref(linkUrl);
	       }
	  }
	  if(is_nextpage_text(eleTextStr)&&!getNextPage)
	  {
	       nsresult rv;
	       if(linkUrl.Length()>0&&linkUrl.Find(NS_ConvertUTF8toUTF16("javascript:"))<0&&linkUrl.Find(NS_ConvertUTF8toUTF16("#"))<0)
	       {
		    mNextPage=do_CreateInstance("@nyapc.com/XPCOM/nsColAtt;1", &rv);
		    if (NS_FAILED(rv))
		    {
			 LOG<<"Get nsWebChannel Error:"<<rv<<"\n";
		    }else
		    {
			  PRInt32 chlId;
			  nsCString strName,strAlias;
			  mCol->GetChlId(&chlId);
			  mCol->GetName(strName);
			  mCol->GetAlias(strAlias);
			  nsCString strUrl(NS_ConvertUTF16toUTF8(linkUrl).get());
			  LOG<<"name:"<<strName.get()<<" url:"<<strUrl.get()<<" chl id:"<<chlId<<"\n";
			  mNextPage->SetCOL(strName,strUrl ,chlId);
			  mNextPage->SetAlias(strAlias);
			  getNextPage=true;
			  break;
		    }
	       }
	       else
	       {
		    nsString onclick;
		    tmpEle->GetAttribute(NS_ConvertUTF8toUTF16("onclick"),onclick);
		    if(onclick.Length()>0)
		    {
			 mEvtEle=tmpEle;
			 getNextPage=true;
			 break;
		    }
	       }
	       
	  }
       
	  if(is_num_text(eleTextStr))
	  {
	       if(linkUrl.Length()>0&&linkUrl.Find(NS_ConvertUTF8toUTF16("javascript:"))<0&&linkUrl.Find(NS_ConvertUTF8toUTF16("#"))<0)
	       {
		    std::string tmpurl=std::string(NS_ConvertUTF16toUTF8(linkUrl).get());
		    bool inClass=false;
		    for(std::list< std::list<std::string> >::iterator it=UrlClass.begin();it!=UrlClass.end();++it)
		    {
			 std::string tmpIn=it->front();
			 if(distance(tmpurl,tmpIn)<=2)
			 {
			      it->push_back(tmpurl);
			      inClass=true;
			 }
		    }
		    if(!inClass)
		    {
			 std::list<std::string> tmpList;
			 tmpList.push_back(tmpurl);
			 UrlClass.push_back(tmpList);
		    }
	       }
	  }
	  
     }
     if(!getNextPage)
     {
	  int MaxCount=0;
	  for(std::list< std::list<std::string> >::iterator it=UrlClass.begin();it!=UrlClass.end();++it)
	  {
	       if(MaxCount<it->size())
		    MaxCount=it->size();
	  }
	  for(std::list< std::list<std::string> >::iterator it=UrlClass.begin();it!=UrlClass.end();++it)
	  {
	       if(MaxCount==it->size())
	       {
		    for(std::list<std::string>::iterator lit=it->begin();lit!=it->end();++lit)
		    {
		    
			 nsresult rv;
			 nsCOMPtr<nsIColAtt> numPage=do_CreateInstance("@nyapc.com/XPCOM/nsColAtt;1", &rv);
			 if (NS_FAILED(rv))
			 {
			      LOG<<"Get nsWebChannel Error:"<<rv<<"\n";
			 }else
			 {
			      PRInt32 chlId;
			      nsCString strName,strAlias;
			      mCol->GetChlId(&chlId);
			      mCol->GetName(strName);
			      mCol->GetAlias(strAlias);
			      nsCString strUrl(lit->c_str());
			      LOG<<"name:"<<strName.get()<<" url:"<<strUrl.get()<<" chl id:"<<chlId<<"\n";
			      numPage->SetCOL(strName,strUrl ,chlId);
			      numPage->SetAlias(strAlias);
			      pages.AppendObject(numPage);
			 }
		    }
		    break;
	       }
	  }
     }
     return NS_OK;
}

bool nsColNextPageFetcher::is_nextpage_text(std::string text)
{
     bool b = false;
     if(text.length()>200)
	  return b;
     int flag = 0;
     regex_t reg;
     int r = regcomp(&reg, "^\\(下.\\{,6\\}页.\\{,6\\}>*\\|>\\+\\)$", flag);
     if(r != 0)
     {
	  char ebuf[128];
	  regerror(r, &reg, ebuf, sizeof(ebuf));
     }
     else
     {
	  size_t nmatch = 1;
	  regmatch_t pm;
	  string_filter(text);
	  int r = regexec(&reg, text.c_str(), nmatch, &pm, 0);
	  if(!r)
	  {
	       b = true;
	  }
     }
     regfree(&reg);

     return b;
}
bool nsColNextPageFetcher::is_num_text(std::string text)
{
     bool b = false;
     if(text.length()>200)
	  return b;
     int flag = 0;
     regex_t reg;
     int r = regcomp(&reg, "^\\([0-9]\\+\\)$", flag);
     if(r != 0)
     {
	  char ebuf[128];
	  regerror(r, &reg, ebuf, sizeof(ebuf));
     }
     else
     {
	  size_t nmatch = 1;
	  regmatch_t pm;
	  string_filter(text);
	  int r = regexec(&reg, text.c_str(), nmatch, &pm, 0);
	  if(!r)
	  {
	       b = true;
	  }
     }
     regfree(&reg);

     return b;
}
/* long GetNumPageCount (); */
NS_IMETHODIMP nsColNextPageFetcher::GetNumPageCount(PRInt32 *_retval)
{
     *_retval=pages.Count();
     return NS_OK;
}

/* void GetNumPage (in long index, out nsIColAtt page); */
NS_IMETHODIMP nsColNextPageFetcher::GetNumPage(PRInt32 index, nsIColAtt **page)
{
      if(index<pages.Count())
     {
	  *page = pages[index];
	  NS_ADDREF(*page);
     }
     else
     {
	  *page=nsnull;
     }
     return NS_OK;
}

void nsColNextPageFetcher::string_filter(std::string & s)
{
     int flag = 0;
     regex_t reg;
     int r = regcomp(&reg, "\\(#\\|\n\\| \\|　\\|\\s\\|\r\\|，\\|。\\|：\\|·\\|“\\|[,.:\"|]\\)\\+", flag);
     if(r != 0)
     {
	  char ebuf[128];
	  regerror(r, &reg, ebuf, sizeof(ebuf));
	  LOG<<"regexp pattern error: "<<ebuf<<"\n";
     }
     else
     {
	  size_t nmatch = 1;
	  regmatch_t pm;
	  int r = regexec(&reg, s.c_str(), nmatch, &pm, 0);
	  if(!r)
	  {
	       int pos = 0;
	       if(pm.rm_so != -1)
	       {
		    int len = pm.rm_eo - pm.rm_so;
		    s.erase(pm.rm_so, len);
		    string_filter(s);
	       }
	  }
     }
     regfree(&reg);
}
int nsColNextPageFetcher::distance(const std::string source, const std::string target) 
{

     // Step 1

     const int n = source.length();
     const int m = target.length();
     if (n == 0) {
	  return m;
     }
     if (m == 0) {
	  return n;
     }

     // Good form to declare a TYPEDEF

     typedef std::vector< std::vector<int> > Tmatrix; 

     Tmatrix matrix(n+1);

     // Size the vectors in the 2.nd dimension. Unfortunately C++ doesn't
     // allow for allocation on declaration of 2.nd dimension of vec of vec

     for (int i = 0; i <= n; i++) {
	  matrix[i].resize(m+1);
     }

     // Step 2

     for (int i = 0; i <= n; i++) {
	  matrix[i][0]=i;
     }

     for (int j = 0; j <= m; j++) {
	  matrix[0][j]=j;
     }

     // Step 3

     for (int i = 1; i <= n; i++) {

	  const char s_i = source[i-1];

	  // Step 4

	  for (int j = 1; j <= m; j++) {

	       const char t_j = target[j-1];

	       // Step 5

	       int cost;
	       if (s_i == t_j) {
		    cost = 0;
	       }
	       else {
		    cost = 1;
	       }

	       // Step 6

	       const int above = matrix[i-1][j];
	       const int left = matrix[i][j-1];
	       const int diag = matrix[i-1][j-1];
	       int cell = std::min( above + 1, std::min(left + 1, diag + cost));

	       // Step 6A: Cover transposition, in addition to deletion,
	       // insertion and substitution. This step is taken from:
	       // Berghel, Hal ; Roach, David : "An Extension of Ukkonen's 
	       // Enhanced Dynamic Programming ASM Algorithm"
	       // (http://www.acm.org/~hlb/publications/asm/asm.html)

	       if (i>2 && j>2) {
		    int trans=matrix[i-2][j-2]+1;
		    if (source[i-2]!=t_j) trans++;
		    if (s_i!=target[j-2]) trans++;
		    if (cell>trans) cell=trans;
	       }

	       matrix[i][j]=cell;
	  }
     }

     // Step 7

     return matrix[n][m];
}
