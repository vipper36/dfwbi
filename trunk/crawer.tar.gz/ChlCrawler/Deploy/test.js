function doXPCOM() {
	try {
		const cid = "@nyapc.com/XPCOM/nsDOMTest;1";
		var obj = Components.classes[cid].createInstance();
		print('queryinterface');
		obj = obj.QueryInterface(Components.interfaces.nsIDOMCluster);
	}
	catch (err) {
		print(err);
		return;
	}

	print('start analysis');
	obj.Analysis('~/workspace/ChlCrawler/blog/dfcf/tt.sqlite');
}
doXPCOM();
