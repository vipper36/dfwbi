#! /bin/bash
. ./config
export DISPLAY

/usr/local/xulrunner-sdk/bin/run-mozilla.sh $CrawlerBin -r 1 -w $CrawlerWorkspace -l $ColListener

unset DISPLAY
