#! /bin/bash
. ./config
export DISPLAY

/usr/local/xulrunner-sdk/bin/run-mozilla.sh $CrawlerBin -w $CrawlerWorkspace -l $ChlListener

unset DISPLAY
