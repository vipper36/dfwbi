/usr/local/xulrunner-sdk/bin/run-mozilla.sh /usr/local/xulrunner-sdk/bin/xpcshell runjs.js $1 $2
