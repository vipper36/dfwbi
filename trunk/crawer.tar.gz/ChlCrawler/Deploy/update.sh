#! /bin/bash
#page=`grep ^ColPageCom Crawler.ini`
#if [ $page ]; then
#    echo "you need to remove the ColPageCom in Crawler.ini"
#    exit
#fi
echo $$>./update.pid
while [ 1 ]; do
./runService ./chlCraw.sh $1
./runService ./colCraw.sh $1
./runService ./conCraw.sh $1
sleep 300    
done

