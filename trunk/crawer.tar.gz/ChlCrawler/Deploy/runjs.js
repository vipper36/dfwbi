function doXPCOM(cid,db) {
	try {
		var obj = Components.classes[cid].createInstance();
		print('queryinterface');
		obj = obj.QueryInterface(Components.interfaces.nsIDOMCluster);
	}
	catch (err) {
		print(err);
		return;
	}

	print('start analysis');
	obj.Analysis(db);
}
print(arguments[0],arguments[1]);
doXPCOM(arguments[0],arguments[1]);