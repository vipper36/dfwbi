#! /bin/bash
#page=`grep ^ColPageCom Crawler.ini`
#if [ -z $page ]; then
#    ehco "you need to add the ColPageCom in Crawler.ini"
#    exit
#fi
echo $$>./his.pid
case "$1" in
    1)
	./runService ./chlCraw.sh $2
	./runService ./colCraw.sh $2
	./runService ./conCraw.sh $2
	;;
    2)
	./runService ./colCraw.sh $2
	./runService ./conCraw.sh $2
	;;
    3)
	./runService ./conCraw.sh $2
	;;
    *)
	echo "Usage: start his {1|2|3} {logfile}"
	;;
esac
if [ -e  his.pid ]; then
    rm his.pid
fi


