/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIColNextPageFetcher.idl
 */

#ifndef __gen_nsIColNextPageFetcher_h__
#define __gen_nsIColNextPageFetcher_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class nsIUrlAtt; /* forward declaration */

class nsIColAtt; /* forward declaration */

class nsIDOMDocument; /* forward declaration */

class nsIDOMElement; /* forward declaration */

class nsIPersistentProperties; /* forward declaration */


/* starting interface:    nsIColNextPageFetcher */
#define NS_ICOLNEXTPAGEFETCHER_IID_STR "ebfa5253-8e57-48b5-90c8-044945eb0501"

#define NS_ICOLNEXTPAGEFETCHER_IID \
  {0xebfa5253, 0x8e57, 0x48b5, \
    { 0x90, 0xc8, 0x04, 0x49, 0x45, 0xeb, 0x05, 0x01 }}

class NS_NO_VTABLE NS_SCRIPTABLE nsIColNextPageFetcher : public nsISupports {
 public: 

  NS_DECLARE_STATIC_IID_ACCESSOR(NS_ICOLNEXTPAGEFETCHER_IID)

  /* attribute nsIColAtt col; */
  NS_SCRIPTABLE NS_IMETHOD GetCol(nsIColAtt * *aCol) = 0;
  NS_SCRIPTABLE NS_IMETHOD SetCol(nsIColAtt * aCol) = 0;

  /* readonly attribute nsIColAtt nextPage; */
  NS_SCRIPTABLE NS_IMETHOD GetNextPage(nsIColAtt * *aNextPage) = 0;

  /* void SetDocument (in nsIDOMDocument doc); */
  NS_SCRIPTABLE NS_IMETHOD SetDocument(nsIDOMDocument *doc) = 0;

  /* void SetProperty (in nsIPersistentProperties prop); */
  NS_SCRIPTABLE NS_IMETHOD SetProperty(nsIPersistentProperties *prop) = 0;

  /* void GetEventEle (out nsIDOMElement ele); */
  NS_SCRIPTABLE NS_IMETHOD GetEventEle(nsIDOMElement **ele) = 0;

  /* long GetNumPageCount (); */
  NS_SCRIPTABLE NS_IMETHOD GetNumPageCount(PRInt32 *_retval) = 0;

  /* void GetNumPage (in long index, out nsIColAtt page); */
  NS_SCRIPTABLE NS_IMETHOD GetNumPage(PRInt32 index, nsIColAtt **page) = 0;

};

  NS_DEFINE_STATIC_IID_ACCESSOR(nsIColNextPageFetcher, NS_ICOLNEXTPAGEFETCHER_IID)

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSICOLNEXTPAGEFETCHER \
  NS_SCRIPTABLE NS_IMETHOD GetCol(nsIColAtt * *aCol); \
  NS_SCRIPTABLE NS_IMETHOD SetCol(nsIColAtt * aCol); \
  NS_SCRIPTABLE NS_IMETHOD GetNextPage(nsIColAtt * *aNextPage); \
  NS_SCRIPTABLE NS_IMETHOD SetDocument(nsIDOMDocument *doc); \
  NS_SCRIPTABLE NS_IMETHOD SetProperty(nsIPersistentProperties *prop); \
  NS_SCRIPTABLE NS_IMETHOD GetEventEle(nsIDOMElement **ele); \
  NS_SCRIPTABLE NS_IMETHOD GetNumPageCount(PRInt32 *_retval); \
  NS_SCRIPTABLE NS_IMETHOD GetNumPage(PRInt32 index, nsIColAtt **page); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSICOLNEXTPAGEFETCHER(_to) \
  NS_SCRIPTABLE NS_IMETHOD GetCol(nsIColAtt * *aCol) { return _to GetCol(aCol); } \
  NS_SCRIPTABLE NS_IMETHOD SetCol(nsIColAtt * aCol) { return _to SetCol(aCol); } \
  NS_SCRIPTABLE NS_IMETHOD GetNextPage(nsIColAtt * *aNextPage) { return _to GetNextPage(aNextPage); } \
  NS_SCRIPTABLE NS_IMETHOD SetDocument(nsIDOMDocument *doc) { return _to SetDocument(doc); } \
  NS_SCRIPTABLE NS_IMETHOD SetProperty(nsIPersistentProperties *prop) { return _to SetProperty(prop); } \
  NS_SCRIPTABLE NS_IMETHOD GetEventEle(nsIDOMElement **ele) { return _to GetEventEle(ele); } \
  NS_SCRIPTABLE NS_IMETHOD GetNumPageCount(PRInt32 *_retval) { return _to GetNumPageCount(_retval); } \
  NS_SCRIPTABLE NS_IMETHOD GetNumPage(PRInt32 index, nsIColAtt **page) { return _to GetNumPage(index, page); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSICOLNEXTPAGEFETCHER(_to) \
  NS_SCRIPTABLE NS_IMETHOD GetCol(nsIColAtt * *aCol) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetCol(aCol); } \
  NS_SCRIPTABLE NS_IMETHOD SetCol(nsIColAtt * aCol) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetCol(aCol); } \
  NS_SCRIPTABLE NS_IMETHOD GetNextPage(nsIColAtt * *aNextPage) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNextPage(aNextPage); } \
  NS_SCRIPTABLE NS_IMETHOD SetDocument(nsIDOMDocument *doc) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetDocument(doc); } \
  NS_SCRIPTABLE NS_IMETHOD SetProperty(nsIPersistentProperties *prop) { return !_to ? NS_ERROR_NULL_POINTER : _to->SetProperty(prop); } \
  NS_SCRIPTABLE NS_IMETHOD GetEventEle(nsIDOMElement **ele) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetEventEle(ele); } \
  NS_SCRIPTABLE NS_IMETHOD GetNumPageCount(PRInt32 *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNumPageCount(_retval); } \
  NS_SCRIPTABLE NS_IMETHOD GetNumPage(PRInt32 index, nsIColAtt **page) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNumPage(index, page); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsColNextPageFetcher : public nsIColNextPageFetcher
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSICOLNEXTPAGEFETCHER

  nsColNextPageFetcher();

private:
  ~nsColNextPageFetcher();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsColNextPageFetcher, nsIColNextPageFetcher)

nsColNextPageFetcher::nsColNextPageFetcher()
{
  /* member initializers and constructor code */
}

nsColNextPageFetcher::~nsColNextPageFetcher()
{
  /* destructor code */
}

/* attribute nsIColAtt col; */
NS_IMETHODIMP nsColNextPageFetcher::GetCol(nsIColAtt * *aCol)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}
NS_IMETHODIMP nsColNextPageFetcher::SetCol(nsIColAtt * aCol)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute nsIColAtt nextPage; */
NS_IMETHODIMP nsColNextPageFetcher::GetNextPage(nsIColAtt * *aNextPage)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetDocument (in nsIDOMDocument doc); */
NS_IMETHODIMP nsColNextPageFetcher::SetDocument(nsIDOMDocument *doc)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void SetProperty (in nsIPersistentProperties prop); */
NS_IMETHODIMP nsColNextPageFetcher::SetProperty(nsIPersistentProperties *prop)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetEventEle (out nsIDOMElement ele); */
NS_IMETHODIMP nsColNextPageFetcher::GetEventEle(nsIDOMElement **ele)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* long GetNumPageCount (); */
NS_IMETHODIMP nsColNextPageFetcher::GetNumPageCount(PRInt32 *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void GetNumPage (in long index, out nsIColAtt page); */
NS_IMETHODIMP nsColNextPageFetcher::GetNumPage(PRInt32 index, nsIColAtt **page)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIColNextPageFetcher_h__ */
