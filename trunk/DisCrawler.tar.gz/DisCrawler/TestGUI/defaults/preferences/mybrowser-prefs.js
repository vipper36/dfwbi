pref("toolkit.defaultChromeURI", "chrome://mybrowser/content/mybrowser.xul");
pref("general.useragent.extra.mybrowser", "MyBrowser/0.1");
