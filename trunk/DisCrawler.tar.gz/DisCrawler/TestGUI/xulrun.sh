cd ../LoginFetch
sudo make install
cd ../TestGUI
/usr/local/xulrunner-sdk/bin/xulrunner --app application.ini -g -rdynamic -d gdb 
