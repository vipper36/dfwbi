
#error This file is now obsolete. Instead include stlsoft/functional/equal_ptr.hpp

/* Compatibility
[<[STLSOFT-AUTO:NO-DOCFILELABEL]>]
[<[STLSOFT-AUTO:NO-UNITTEST]>]
*/

/* ///////////////////////////// end of file //////////////////////////// */